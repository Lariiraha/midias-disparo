# Roteiro de Coleta — Performance do Produto via Claude in Chrome

Este documento detalha passo a passo como navegar no Seller Center para coletar os dados de performance de produto e reputação da loja.

## Pré-requisitos

- Claude in Chrome ativo e conectado
- Seller Center JÁ LOGADO no Chrome do usuário
- Período de análise: Últimos 30 dias (pedido pago)

---

## BLOCO 1: Performance do Produto

### Passo 1 — Abrir Seller Center

```
1. tabs_context_mcp(createIfEmpty: true) → anotar tabId
2. navigate(tabId, "https://seller.shopee.com.br")
3. computer(action: "wait", tabId, duration: 3)
4. computer(action: "screenshot", tabId)
   → Se LOGIN: avisar usuário e aguardar
   → Se painel: continuar
```

### Passo 2 — Navegar ao menu de Performance

```
1. find(tabId, "Informações Gerenciais") → clicar
2. computer(action: "wait", tabId, duration: 2)
3. find(tabId, "Produto") → clicar
   → Alternativas: find(tabId, "Performance do Produto") ou find(tabId, "Produtos")
4. computer(action: "wait", tabId, duration: 3)
5. computer(action: "screenshot", tabId)
   → Confirmar: estou na página de Performance do Produto?
```

### Passo 3 — Configurar período (30 dias, pedido pago)

```
1. Procurar seletor de período no topo da página
   → find(tabId, "30 dias") ou find(tabId, "Últimos 30 dias")
   → Se não encontrar: screenshot e procurar visualmente o date picker

2. Verificar se a base é "Pedido pago" (não "Pedido criado")
   → find(tabId, "Pedido pago") ou find(tabId, "pedido pago")
   → Selecionar se necessário

3. computer(action: "wait", tabId, duration: 3)
4. screenshot → confirmar período e base corretos
```

### Passo 4 — Extrair tabela de produtos

```
MÉTODO 1 — JavaScript (mais confiável para tabelas grandes):

javascript_tool(tabId, action: "javascript_exec", text: `
  const rows = document.querySelectorAll('table tbody tr');
  const headers = Array.from(document.querySelectorAll('table thead th')).map(h => h.textContent.trim());
  const data = [];
  rows.forEach(row => {
    const cells = row.querySelectorAll('td');
    const rowData = {};
    cells.forEach((cell, i) => {
      rowData[headers[i] || 'col_' + i] = cell.textContent.trim();
    });
    data.push(rowData);
  });
  JSON.stringify({ headers, total_rows: data.length, data }, null, 2);
`)

MÉTODO 2 — get_page_text (fallback):

get_page_text(tabId) → parsear manualmente a tabela do texto
```

### Passo 5 — Navegar por TODAS as páginas

```
1. Verificar total de produtos indicado na página (ex: "Mostrando 1-20 de 85")
2. Contar produtos coletados vs total

3. Enquanto houver mais páginas:
   → find(tabId, "Próxima") ou find(tabId, ">") ou find(tabId, "next")
   → computer(action: "wait", tabId, duration: 2)
   → Repetir extração (Passo 4)
   → Acumular dados

4. Confirmar: total coletado == total indicado na página

ALTERNATIVA — Se tiver opção de "mostrar todos":
   → find(tabId, "100") ou find(tabId, "Todos") no seletor de itens por página
   → Selecionar para mostrar o máximo possível por página
   → Reduz o número de páginas a navegar
```

### Passo 6 — Validar dados coletados

```
Para cada produto-pai (impressão com valor numérico, não "-"):

Campos obrigatórios:
  ☑ ID do Item
  ☑ Impressão do Produto
  ☑ CTR (%)
  ☑ Visitantes do Produto
  ☑ Visitantes que Adicionaram ao Carrinho (ou Taxa de Adição ao Carrinho)
  ☑ Taxa de Conversão de Adição ao Carrinho
  ☑ Pedidos (Pedido Pago)

Se algum campo estiver ausente:
  → Verificar se a tabela tem colunas ocultas
  → find(tabId, "Personalizar colunas") ou find(tabId, "Colunas")
  → Adicionar as colunas faltantes
  → Recarregar e re-extrair
```

---

## BLOCO 2: Reputação e Penalidades

### Passo 7 — Navegar até Desempenho da Loja

```
1. find(tabId, "Desempenho da Loja") ou find(tabId, "Saúde da Loja") ou find(tabId, "Shop Performance")
   → clicar
2. computer(action: "wait", tabId, duration: 3)
3. computer(action: "screenshot", tabId)
```

### Passo 8 — Coletar dados de reputação

```
1. get_page_text(tabId) → extrair:

   PENALIDADES:
   - Pontos de penalidade ativos: [número]
   - Tipo de penalidade (se listado): [descrição]

   STATUS:
   - Classificação da loja: [Excelente / Bom / Precisa Melhorar]

   TAXAS OPERACIONAIS:
   - Taxa de não cumprimento: [%]
   - Taxa de cancelamento: [%]
   - Taxa de envio atrasado: [%]
   - Tempo médio de preparação: [dias]

   AVALIAÇÕES:
   - Nota média da loja: [estrelas]

2. Se necessário, scroll para ver todas as métricas:
   computer(action: "scroll", tabId, coordinate: [640, 400], scroll_direction: "down", scroll_amount: 5)
   screenshot → ler dados adicionais

3. Guardar tudo em objeto de reputação
```

---

## BLOCO 3: Consolidação

```
Ao final da coleta:

1. Confirmar totais:
   - Total de produtos-pai coletados: [N]
   - Dados de reputação: [OK / Incompleto]

2. Se algo faltou:
   → Tentar novamente a coleta específica
   → Se impossível, registrar como "N/A" e avisar usuário

3. Informar ao usuário:
   "Coleta finalizada! Encontrei [N] produtos e verifiquei a reputação da loja.
    Vou analisar o funil de cada produto e gerar o relatório..."
```

---

## Dicas de Navegação

- **Seller Center é SPA React**: menus podem não estar no DOM até serem abertos. Use `find()` por texto, não por seletores CSS fixos.
- **Sempre wait(2-3s)** após clicar em menus antes de ler conteúdo.
- **Pop-ups**: fechar com `find(tabId, "fechar")` ou `key("Escape")`.
- **Tabelas paginadas**: NUNCA parar antes de ler todas as páginas.
- **Números brasileiros**: "1.234" = 1234, "2,39%" = 2.39.
- **Se read_page retornar vazio**: tentar `get_page_text` ou JavaScript como alternativa.
