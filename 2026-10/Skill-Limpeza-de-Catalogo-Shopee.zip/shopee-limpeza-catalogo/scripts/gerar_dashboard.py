#!/usr/bin/env python3
"""
Shopee Limpeza de Catálogo — Gerador de Dashboard
Processa planilha exportada do Seller Center e gera dashboard HTML interativo.
"""

import argparse
import json
import sys
import re
from pathlib import Path

try:
    import openpyxl
except ImportError:
    print("Instalando openpyxl...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "openpyxl", "--break-system-packages", "-q"])
    import openpyxl


def parse_br_number(value):
    """Parse número no formato brasileiro (1.234,56 ou 2,39%)"""
    if value is None or value == '-' or value == '':
        return 0.0
    s = str(value).strip().replace('%', '')
    # Formato brasileiro: 1.234,56 → remove pontos de milhar, troca vírgula por ponto
    # Detect: if has both . and , then it's BR format
    if '.' in s and ',' in s:
        s = s.replace('.', '').replace(',', '.')
    elif ',' in s:
        s = s.replace(',', '.')
    try:
        return float(s)
    except ValueError:
        return 0.0


def find_column_index(headers, *possible_names):
    """Find column index by trying multiple possible names (case-insensitive partial match)"""
    for name in possible_names:
        for i, h in enumerate(headers):
            if h and name.lower() in str(h).lower():
                return i
    return None


def load_products(filepath):
    """Load parent-level products from the Excel file"""
    wb = openpyxl.load_workbook(filepath)

    # Try to find the main sheet
    target_sheet = None
    for name in wb.sheetnames:
        if 'melhor desempenho' in name.lower() or 'desempenho' in name.lower():
            target_sheet = name
            break
    if not target_sheet:
        target_sheet = wb.sheetnames[0]

    ws = wb[target_sheet]
    headers = [cell.value for cell in ws[1]]

    # Map columns
    col_id = find_column_index(headers, 'ID do Item', 'ID do Produto', 'ID Item')
    col_nome = find_column_index(headers, 'Produto', 'Nome do Produto')
    col_imp = find_column_index(headers, 'Impressão do Produto', 'Impressões do Produto')
    col_clicks = find_column_index(headers, 'Cliques Por Produto', 'Cliques por Produto')
    col_visitantes = find_column_index(headers, 'Visitantes do Produto (Visita)')
    col_ctr = find_column_index(headers, 'CTR')
    col_conv_carrinho = find_column_index(headers, 'Taxa de Conversão (adicionar ao carrinho)', 'Conversão (adicionar ao carrinho)')
    col_conv_pedido = find_column_index(headers, 'Taxa de Conversão de Pedido (Pedido Pago)', 'Conversão de Pedido (Pedido Pago)')
    col_vendas = find_column_index(headers, 'Vendas (Pedido pago)', 'Vendas (Pedido Pago)')
    col_unidades = find_column_index(headers, 'Unidades (Pedido pago)', 'Unidades (pedido pago)')

    if col_id is None or col_imp is None:
        print(f"Erro: Colunas obrigatórias não encontradas. Headers: {headers}")
        sys.exit(1)

    products = []
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row, values_only=True):
        imp_raw = row[col_imp] if col_imp is not None else None
        if imp_raw is None or imp_raw == '-' or str(imp_raw).strip() == '':
            continue  # Skip variation rows

        imp = parse_br_number(imp_raw)

        product = {
            'id': str(row[col_id]) if col_id is not None else '',
            'nome': str(row[col_nome])[:80] if col_nome is not None and row[col_nome] else 'Sem nome',
            'impressoes': imp,
            'cliques': parse_br_number(row[col_clicks]) if col_clicks is not None else 0,
            'visitantes': parse_br_number(row[col_visitantes]) if col_visitantes is not None else 0,
            'ctr': parse_br_number(row[col_ctr]) if col_ctr is not None else 0,
            'conv_carrinho': parse_br_number(row[col_conv_carrinho]) if col_conv_carrinho is not None else 0,
            'conv_pedido': parse_br_number(row[col_conv_pedido]) if col_conv_pedido is not None else 0,
            'vendas': parse_br_number(row[col_vendas]) if col_vendas is not None else 0,
            'unidades': parse_br_number(row[col_unidades]) if col_unidades is not None else 0,
        }
        products.append(product)

    return products


def classify_products(products, ids_novos):
    """Classify each product into: excluir, atencao, saudavel, novo"""
    if not products:
        return products

    n = len(products)
    avg_imp = sum(p['impressoes'] for p in products) / n
    avg_conv = sum(p['conv_pedido'] for p in products) / n
    avg_ctr = sum(p['ctr'] for p in products) / n
    avg_clicks = sum(p['cliques'] for p in products) / n
    avg_vendas = sum(p['vendas'] for p in products) / n

    stats = {
        'total': n,
        'avg_imp': avg_imp,
        'avg_conv': avg_conv,
        'avg_ctr': avg_ctr,
        'avg_clicks': avg_clicks,
        'avg_vendas': avg_vendas,
        'total_vendas': sum(p['vendas'] for p in products),
        'total_unidades': sum(p['unidades'] for p in products),
    }

    for p in products:
        p['is_novo'] = p['id'] in ids_novos

        if p['is_novo']:
            p['classificacao'] = 'novo'
            p['criterio'] = 'Produto com menos de 90 dias — em maturação'
            continue

        # Critério 1: Fantasma (impressão > 0, cliques = 0)
        if p['impressoes'] > 0 and p['cliques'] == 0:
            p['classificacao'] = 'excluir'
            p['criterio'] = 'Fantasma — Tem impressões mas ZERO cliques'
            continue

        # Critério 2: Vitrine quebrada (imp > média, CTR < 1.5%, conv < média)
        if (p['impressoes'] >= avg_imp and p['ctr'] < 1.5 and p['conv_pedido'] < avg_conv):
            p['classificacao'] = 'excluir'
            p['criterio'] = 'Vitrine quebrada — Impressões acima da média mas CTR < 1,5% e conversão abaixo da média'
            continue

        # Critério 3: Invisível (imp < média)
        if p['impressoes'] < avg_imp:
            p['classificacao'] = 'excluir'
            p['criterio'] = 'Invisível — Impressões abaixo da média da conta'
            continue

        # Curva C: conversão abaixo da média
        if p['conv_pedido'] < avg_conv:
            p['classificacao'] = 'atencao'
            p['criterio'] = 'Curva C — Conversão abaixo da média da conta'
            continue

        # Saudável
        p['classificacao'] = 'saudavel'
        p['criterio'] = 'Produto saudável — Performance dentro ou acima da média'

    return products, stats


def generate_dashboard_html(products, stats, ids_novos):
    """Generate the full HTML dashboard"""

    counts = {
        'excluir': len([p for p in products if p['classificacao'] == 'excluir']),
        'atencao': len([p for p in products if p['classificacao'] == 'atencao']),
        'saudavel': len([p for p in products if p['classificacao'] == 'saudavel']),
        'novo': len([p for p in products if p['classificacao'] == 'novo']),
    }

    # Subcounts for exclusion criteria
    fantasma = [p for p in products if p['classificacao'] == 'excluir' and 'Fantasma' in p['criterio']]
    vitrine = [p for p in products if p['classificacao'] == 'excluir' and 'Vitrine' in p['criterio']]
    invisivel = [p for p in products if p['classificacao'] == 'excluir' and 'Invisível' in p['criterio']]

    products_json = json.dumps(products, ensure_ascii=False)
    stats_json = json.dumps(stats, ensure_ascii=False)
    counts_json = json.dumps(counts, ensure_ascii=False)

    html = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Limpeza de Catálogo Shopee — Dashboard</title>
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{
  font-family: system-ui, -apple-system, sans-serif;
  background: #0f0f1a;
  color: #e0e0e0;
  min-height: 100vh;
  padding: 20px;
}}
.container {{ max-width: 1400px; margin: 0 auto; }}

/* Header */
.header {{
  text-align: center;
  padding: 30px 20px;
  margin-bottom: 30px;
  background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
  border-radius: 16px;
  border: 1px solid rgba(255,255,255,0.05);
}}
.header h1 {{
  font-size: 28px;
  font-weight: 700;
  background: linear-gradient(135deg, #00b894, #3498db);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin-bottom: 8px;
}}
.header p {{ color: #888; font-size: 14px; }}

/* Stats Cards */
.stats-grid {{
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  margin-bottom: 30px;
}}
.stat-card {{
  background: #1a1a2e;
  border-radius: 12px;
  padding: 20px;
  border: 1px solid rgba(255,255,255,0.05);
  text-align: center;
}}
.stat-card .value {{
  font-size: 32px;
  font-weight: 700;
  margin-bottom: 4px;
}}
.stat-card .label {{
  font-size: 12px;
  color: #888;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}}
.stat-card.excluir .value {{ color: #e74c3c; }}
.stat-card.atencao .value {{ color: #f39c12; }}
.stat-card.saudavel .value {{ color: #00b894; }}
.stat-card.novo .value {{ color: #3498db; }}
.stat-card.neutral .value {{ color: #a0a0a0; }}

/* Distribution Bar */
.dist-bar-container {{
  margin-bottom: 30px;
  background: #1a1a2e;
  border-radius: 12px;
  padding: 20px;
  border: 1px solid rgba(255,255,255,0.05);
}}
.dist-bar {{
  display: flex;
  height: 36px;
  border-radius: 8px;
  overflow: hidden;
  margin-top: 12px;
}}
.dist-bar div {{
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
  color: white;
  transition: all 0.3s;
}}
.dist-bar div:hover {{ opacity: 0.85; }}
.dist-bar .excluir {{ background: #e74c3c; }}
.dist-bar .atencao {{ background: #f39c12; }}
.dist-bar .saudavel {{ background: #00b894; }}
.dist-bar .novo {{ background: #3498db; }}

/* Averages */
.averages {{
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 12px;
  margin-bottom: 30px;
}}
.avg-card {{
  background: #1a1a2e;
  border-radius: 10px;
  padding: 16px;
  border: 1px solid rgba(255,255,255,0.05);
  text-align: center;
}}
.avg-card .avg-value {{
  font-size: 22px;
  font-weight: 700;
  color: #74b9ff;
}}
.avg-card .avg-label {{
  font-size: 11px;
  color: #888;
  margin-top: 4px;
}}

/* Section */
.section {{
  margin-bottom: 30px;
}}
.section-header {{
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
  padding: 16px 20px;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s;
}}
.section-header:hover {{ opacity: 0.9; }}
.section-header.excluir {{ background: linear-gradient(135deg, rgba(231,76,60,0.15), rgba(231,76,60,0.05)); border-left: 4px solid #e74c3c; }}
.section-header.atencao {{ background: linear-gradient(135deg, rgba(243,156,18,0.15), rgba(243,156,18,0.05)); border-left: 4px solid #f39c12; }}
.section-header.saudavel {{ background: linear-gradient(135deg, rgba(0,184,148,0.15), rgba(0,184,148,0.05)); border-left: 4px solid #00b894; }}
.section-header.novo {{ background: linear-gradient(135deg, rgba(52,152,219,0.15), rgba(52,152,219,0.05)); border-left: 4px solid #3498db; }}
.section-header h2 {{ font-size: 18px; flex: 1; }}
.section-header .count {{
  font-size: 14px;
  padding: 4px 12px;
  border-radius: 20px;
  font-weight: 600;
}}
.section-header.excluir .count {{ background: rgba(231,76,60,0.2); color: #e74c3c; }}
.section-header.atencao .count {{ background: rgba(243,156,18,0.2); color: #f39c12; }}
.section-header.saudavel .count {{ background: rgba(0,184,148,0.2); color: #00b894; }}
.section-header.novo .count {{ background: rgba(52,152,219,0.2); color: #3498db; }}
.section-header .arrow {{
  font-size: 18px;
  transition: transform 0.3s;
  color: #888;
}}
.section-header .arrow.open {{ transform: rotate(180deg); }}

/* Subcriteria badges */
.subcriteria {{
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}}
.subcriteria .badge {{
  padding: 6px 14px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 500;
}}
.badge.fantasma {{ background: rgba(231,76,60,0.15); color: #e74c3c; border: 1px solid rgba(231,76,60,0.3); }}
.badge.vitrine {{ background: rgba(230,126,34,0.15); color: #e67e22; border: 1px solid rgba(230,126,34,0.3); }}
.badge.invisivel {{ background: rgba(192,57,43,0.15); color: #c0392b; border: 1px solid rgba(192,57,43,0.3); }}

/* Table */
.table-container {{
  overflow-x: auto;
  border-radius: 12px;
  border: 1px solid rgba(255,255,255,0.05);
}}
table {{
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}}
th {{
  background: #16213e;
  padding: 12px 16px;
  text-align: left;
  font-weight: 600;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #888;
  cursor: pointer;
  user-select: none;
  white-space: nowrap;
  position: sticky;
  top: 0;
}}
th:hover {{ color: #ccc; }}
th .sort-arrow {{ margin-left: 4px; opacity: 0.5; }}
td {{
  padding: 10px 16px;
  border-bottom: 1px solid rgba(255,255,255,0.03);
  white-space: nowrap;
}}
tr {{ background: #1a1a2e; transition: background 0.15s; }}
tr:hover {{ background: #1f2a40; }}
tr.excluir {{ border-left: 3px solid #e74c3c; }}
tr.atencao {{ border-left: 3px solid #f39c12; }}
tr.saudavel {{ border-left: 3px solid #00b894; }}
tr.novo {{ border-left: 3px solid #3498db; }}
.tag {{
  display: inline-block;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
}}
.tag.excluir {{ background: rgba(231,76,60,0.2); color: #e74c3c; }}
.tag.atencao {{ background: rgba(243,156,18,0.2); color: #f39c12; }}
.tag.saudavel {{ background: rgba(0,184,148,0.2); color: #00b894; }}
.tag.novo {{ background: rgba(52,152,219,0.2); color: #3498db; }}

.criterio-text {{
  font-size: 11px;
  color: #888;
  max-width: 300px;
  white-space: normal;
  line-height: 1.4;
}}

/* Metric indicators */
.metric-bad {{ color: #e74c3c; }}
.metric-warn {{ color: #f39c12; }}
.metric-good {{ color: #00b894; }}

/* Filter bar */
.filter-bar {{
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  flex-wrap: wrap;
  align-items: center;
}}
.filter-btn {{
  padding: 8px 16px;
  border-radius: 8px;
  border: 1px solid rgba(255,255,255,0.1);
  background: #1a1a2e;
  color: #ccc;
  cursor: pointer;
  font-size: 13px;
  transition: all 0.2s;
}}
.filter-btn:hover {{ border-color: rgba(255,255,255,0.3); }}
.filter-btn.active {{ border-color: #3498db; background: rgba(52,152,219,0.15); color: white; }}
.search-input {{
  padding: 8px 16px;
  border-radius: 8px;
  border: 1px solid rgba(255,255,255,0.1);
  background: #1a1a2e;
  color: #e0e0e0;
  font-size: 13px;
  flex: 1;
  min-width: 200px;
}}
.search-input:focus {{ outline: none; border-color: #3498db; }}
.search-input::placeholder {{ color: #555; }}

/* Section content */
.section-content {{
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.4s ease;
}}
.section-content.open {{
  max-height: 5000px;
}}

/* Footer */
.footer {{
  text-align: center;
  padding: 20px;
  margin-top: 30px;
  color: #555;
  font-size: 12px;
}}

/* Responsive */
@media (max-width: 768px) {{
  body {{ padding: 10px; }}
  .stats-grid {{ grid-template-columns: repeat(2, 1fr); }}
  .header h1 {{ font-size: 22px; }}
  td, th {{ padding: 8px 10px; font-size: 12px; }}
}}
</style>
</head>
<body>
<div class="container">

<div class="header">
  <h1>Limpeza de Catálogo Shopee</h1>
  <p>Análise de performance dos produtos — Últimos 30 dias (Pedido Pago)</p>
</div>

<!-- Stats Cards -->
<div class="stats-grid">
  <div class="stat-card neutral">
    <div class="value" id="total-count"></div>
    <div class="label">Produtos Analisados</div>
  </div>
  <div class="stat-card excluir">
    <div class="value" id="excluir-count"></div>
    <div class="label">Para Excluir</div>
  </div>
  <div class="stat-card atencao">
    <div class="value" id="atencao-count"></div>
    <div class="label">Curva C (Atenção)</div>
  </div>
  <div class="stat-card saudavel">
    <div class="value" id="saudavel-count"></div>
    <div class="label">Saudáveis</div>
  </div>
  <div class="stat-card novo">
    <div class="value" id="novo-count"></div>
    <div class="label">Novos (&lt;90 dias)</div>
  </div>
</div>

<!-- Distribution Bar -->
<div class="dist-bar-container">
  <div style="display:flex;justify-content:space-between;align-items:center;">
    <span style="font-weight:600;">Distribuição do Catálogo</span>
    <span style="font-size:12px;color:#888;" id="dist-legend"></span>
  </div>
  <div class="dist-bar" id="dist-bar"></div>
</div>

<!-- Averages -->
<div class="averages">
  <div class="avg-card">
    <div class="avg-value" id="avg-imp"></div>
    <div class="avg-label">Média de Impressões</div>
  </div>
  <div class="avg-card">
    <div class="avg-value" id="avg-clicks"></div>
    <div class="avg-label">Média de Cliques</div>
  </div>
  <div class="avg-card">
    <div class="avg-value" id="avg-ctr"></div>
    <div class="avg-label">Média CTR</div>
  </div>
  <div class="avg-card">
    <div class="avg-value" id="avg-conv"></div>
    <div class="avg-label">Média Conversão (Pedido)</div>
  </div>
  <div class="avg-card">
    <div class="avg-value" id="total-vendas"></div>
    <div class="avg-label">Faturamento Total (30d)</div>
  </div>
</div>

<!-- Sections -->
<div id="sections-container"></div>

<!-- Full Table -->
<div class="section" style="margin-top: 40px;">
  <h2 style="font-size:20px;margin-bottom:16px;">Tabela Completa</h2>
  <div class="filter-bar">
    <button class="filter-btn active" data-filter="todos">Todos</button>
    <button class="filter-btn" data-filter="excluir">Excluir</button>
    <button class="filter-btn" data-filter="atencao">Curva C</button>
    <button class="filter-btn" data-filter="saudavel">Saudáveis</button>
    <button class="filter-btn" data-filter="novo">Novos</button>
    <input type="text" class="search-input" placeholder="Buscar por nome ou ID..." id="search-input">
  </div>
  <div class="table-container">
    <table id="full-table">
      <thead>
        <tr>
          <th data-sort="classificacao">Status <span class="sort-arrow"></span></th>
          <th data-sort="id">ID <span class="sort-arrow"></span></th>
          <th data-sort="nome">Produto <span class="sort-arrow"></span></th>
          <th data-sort="impressoes">Impressões <span class="sort-arrow"></span></th>
          <th data-sort="cliques">Cliques <span class="sort-arrow"></span></th>
          <th data-sort="visitantes">Visitantes <span class="sort-arrow"></span></th>
          <th data-sort="ctr">CTR <span class="sort-arrow"></span></th>
          <th data-sort="conv_carrinho">Conv. Carrinho <span class="sort-arrow"></span></th>
          <th data-sort="conv_pedido">Conv. Pedido <span class="sort-arrow"></span></th>
          <th data-sort="vendas">Vendas (R$) <span class="sort-arrow"></span></th>
          <th data-sort="unidades">Unidades <span class="sort-arrow"></span></th>
          <th>Critério</th>
        </tr>
      </thead>
      <tbody id="full-table-body"></tbody>
    </table>
  </div>
</div>

<div class="footer">
  Limpeza de Catálogo Shopee — Gerado automaticamente com base nos dados do Seller Center
</div>

</div>

<script>
const PRODUCTS = {products_json};
const STATS = {stats_json};
const COUNTS = {counts_json};

// Format numbers
function fmtNum(n) {{ return n.toLocaleString('pt-BR', {{maximumFractionDigits: 0}}); }}
function fmtDec(n) {{ return n.toLocaleString('pt-BR', {{minimumFractionDigits: 2, maximumFractionDigits: 2}}); }}
function fmtBRL(n) {{ return 'R$ ' + n.toLocaleString('pt-BR', {{minimumFractionDigits: 2, maximumFractionDigits: 2}}); }}
function fmtPct(n) {{ return n.toLocaleString('pt-BR', {{minimumFractionDigits: 2, maximumFractionDigits: 2}}) + '%'; }}

// Populate stats
document.getElementById('total-count').textContent = STATS.total;
document.getElementById('excluir-count').textContent = COUNTS.excluir;
document.getElementById('atencao-count').textContent = COUNTS.atencao;
document.getElementById('saudavel-count').textContent = COUNTS.saudavel;
document.getElementById('novo-count').textContent = COUNTS.novo;
document.getElementById('avg-imp').textContent = fmtNum(STATS.avg_imp);
document.getElementById('avg-clicks').textContent = fmtNum(STATS.avg_clicks);
document.getElementById('avg-ctr').textContent = fmtPct(STATS.avg_ctr);
document.getElementById('avg-conv').textContent = fmtPct(STATS.avg_conv);
document.getElementById('total-vendas').textContent = fmtBRL(STATS.total_vendas);

// Distribution bar
const total = STATS.total;
const distBar = document.getElementById('dist-bar');
const sections = [
  {{ cls: 'excluir', count: COUNTS.excluir, label: 'Excluir' }},
  {{ cls: 'atencao', count: COUNTS.atencao, label: 'Atenção' }},
  {{ cls: 'saudavel', count: COUNTS.saudavel, label: 'Saudável' }},
  {{ cls: 'novo', count: COUNTS.novo, label: 'Novo' }},
];
sections.forEach(s => {{
  if (s.count > 0) {{
    const pct = (s.count / total * 100);
    const div = document.createElement('div');
    div.className = s.cls;
    div.style.width = pct + '%';
    div.textContent = pct >= 8 ? s.count + ' (' + Math.round(pct) + '%)' : s.count;
    distBar.appendChild(div);
  }}
}});

// Color helpers
function ctrClass(v) {{ return v >= 1.5 ? 'metric-good' : v >= 1.0 ? 'metric-warn' : 'metric-bad'; }}
function convClass(v) {{ return v >= STATS.avg_conv ? 'metric-good' : v > 0 ? 'metric-warn' : 'metric-bad'; }}
function impClass(v) {{ return v >= STATS.avg_imp ? 'metric-good' : 'metric-warn'; }}

// Section builder
const sectionsConfig = [
  {{
    cls: 'excluir',
    title: 'Produtos para Excluir',
    emoji: '🗑️',
    filter: p => p.classificacao === 'excluir',
  }},
  {{
    cls: 'atencao',
    title: 'Curva C — Precisam de Atenção',
    emoji: '⚠️',
    filter: p => p.classificacao === 'atencao',
  }},
  {{
    cls: 'saudavel',
    title: 'Produtos Saudáveis',
    emoji: '✅',
    filter: p => p.classificacao === 'saudavel',
  }},
  {{
    cls: 'novo',
    title: 'Produtos Novos (< 90 dias)',
    emoji: '🆕',
    filter: p => p.classificacao === 'novo',
  }},
];

const sectionsContainer = document.getElementById('sections-container');
sectionsConfig.forEach((sec, idx) => {{
  const items = PRODUCTS.filter(sec.filter);
  if (items.length === 0) return;

  const sectionDiv = document.createElement('div');
  sectionDiv.className = 'section';

  const headerId = 'section-header-' + idx;
  const contentId = 'section-content-' + idx;

  let subcriteria = '';
  if (sec.cls === 'excluir') {{
    const fantasma = items.filter(p => p.criterio.includes('Fantasma')).length;
    const vitrine = items.filter(p => p.criterio.includes('Vitrine')).length;
    const invisivel = items.filter(p => p.criterio.includes('Invisível')).length;
    subcriteria = `<div class="subcriteria">
      ${{fantasma > 0 ? `<span class="badge fantasma">👻 Fantasma: ${{fantasma}}</span>` : ''}}
      ${{vitrine > 0 ? `<span class="badge vitrine">🪟 Vitrine quebrada: ${{vitrine}}</span>` : ''}}
      ${{invisivel > 0 ? `<span class="badge invisivel">👁️ Invisível: ${{invisivel}}</span>` : ''}}
    </div>`;
  }}

  sectionDiv.innerHTML = `
    <div class="section-header ${{sec.cls}}" id="${{headerId}}" onclick="toggleSection('${{contentId}}', '${{headerId}}')">
      <span style="font-size:22px;">${{sec.emoji}}</span>
      <h2>${{sec.title}}</h2>
      <span class="count">${{items.length}} produto${{items.length > 1 ? 's' : ''}}</span>
      <span class="arrow" id="${{headerId}}-arrow">▼</span>
    </div>
    <div class="section-content ${{idx === 0 ? 'open' : ''}}" id="${{contentId}}">
      ${{subcriteria}}
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Produto</th>
              <th>Impressões</th>
              <th>Cliques</th>
              <th>CTR</th>
              <th>Conv. Pedido</th>
              <th>Vendas (R$)</th>
              <th>Critério</th>
            </tr>
          </thead>
          <tbody>
            ${{items.map(p => `
              <tr class="${{sec.cls}}">
                <td>${{p.id}}</td>
                <td style="max-width:250px;white-space:normal;line-height:1.3;">${{p.nome}}</td>
                <td class="${{impClass(p.impressoes)}}">${{fmtNum(p.impressoes)}}</td>
                <td>${{fmtNum(p.cliques)}}</td>
                <td class="${{ctrClass(p.ctr)}}">${{fmtPct(p.ctr)}}</td>
                <td class="${{convClass(p.conv_pedido)}}">${{fmtPct(p.conv_pedido)}}</td>
                <td>${{fmtBRL(p.vendas)}}</td>
                <td class="criterio-text">${{p.criterio}}</td>
              </tr>
            `).join('')}}
          </tbody>
        </table>
      </div>
    </div>
  `;
  sectionsContainer.appendChild(sectionDiv);

  // Auto-open first section
  if (idx === 0) {{
    document.getElementById(headerId + '-arrow').classList.add('open');
  }}
}});

function toggleSection(contentId, headerId) {{
  const content = document.getElementById(contentId);
  const arrow = document.getElementById(headerId + '-arrow');
  content.classList.toggle('open');
  arrow.classList.toggle('open');
}}

// Full table
let currentFilter = 'todos';
let currentSearch = '';
let sortCol = null;
let sortDir = 1;

function renderFullTable() {{
  const tbody = document.getElementById('full-table-body');
  let filtered = PRODUCTS.filter(p => {{
    if (currentFilter !== 'todos' && p.classificacao !== currentFilter) return false;
    if (currentSearch) {{
      const q = currentSearch.toLowerCase();
      return p.nome.toLowerCase().includes(q) || p.id.includes(q);
    }}
    return true;
  }});

  if (sortCol) {{
    filtered.sort((a, b) => {{
      let va = a[sortCol], vb = b[sortCol];
      if (typeof va === 'string') return va.localeCompare(vb) * sortDir;
      return (va - vb) * sortDir;
    }});
  }}

  tbody.innerHTML = filtered.map(p => `
    <tr class="${{p.classificacao}}">
      <td><span class="tag ${{p.classificacao}}">${{
        p.classificacao === 'excluir' ? 'EXCLUIR' :
        p.classificacao === 'atencao' ? 'ATENÇÃO' :
        p.classificacao === 'saudavel' ? 'OK' : 'NOVO'
      }}</span></td>
      <td>${{p.id}}</td>
      <td style="max-width:200px;white-space:normal;line-height:1.3;">${{p.nome}}</td>
      <td class="${{impClass(p.impressoes)}}">${{fmtNum(p.impressoes)}}</td>
      <td>${{fmtNum(p.cliques)}}</td>
      <td>${{fmtNum(p.visitantes)}}</td>
      <td class="${{ctrClass(p.ctr)}}">${{fmtPct(p.ctr)}}</td>
      <td>${{fmtPct(p.conv_carrinho)}}</td>
      <td class="${{convClass(p.conv_pedido)}}">${{fmtPct(p.conv_pedido)}}</td>
      <td>${{fmtBRL(p.vendas)}}</td>
      <td>${{fmtNum(p.unidades)}}</td>
      <td class="criterio-text">${{p.criterio}}</td>
    </tr>
  `).join('');
}}

// Filter buttons
document.querySelectorAll('.filter-btn').forEach(btn => {{
  btn.addEventListener('click', () => {{
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    renderFullTable();
  }});
}});

// Search
document.getElementById('search-input').addEventListener('input', (e) => {{
  currentSearch = e.target.value;
  renderFullTable();
}});

// Sort
document.querySelectorAll('#full-table th[data-sort]').forEach(th => {{
  th.addEventListener('click', () => {{
    const col = th.dataset.sort;
    if (sortCol === col) {{
      sortDir *= -1;
    }} else {{
      sortCol = col;
      sortDir = 1;
    }}
    renderFullTable();
  }});
}});

renderFullTable();
</script>
</body>
</html>"""

    return html


def main():
    parser = argparse.ArgumentParser(description='Shopee Limpeza de Catálogo — Gerador de Dashboard')
    parser.add_argument('--input', required=True, help='Caminho da planilha .xlsx')
    parser.add_argument('--output', required=True, help='Caminho do arquivo HTML de saída')
    parser.add_argument('--ids-novos', default='', help='IDs de produtos novos (<90 dias), separados por vírgula')

    args = parser.parse_args()

    ids_novos = set()
    if args.ids_novos:
        ids_novos = set(id.strip() for id in args.ids_novos.split(',') if id.strip())

    print(f"Carregando planilha: {args.input}")
    products = load_products(args.input)
    print(f"Produtos-pai encontrados: {len(products)}")

    print(f"IDs novos (<90 dias): {ids_novos if ids_novos else 'nenhum'}")

    products, stats = classify_products(products, ids_novos)

    counts = {}
    for cls in ['excluir', 'atencao', 'saudavel', 'novo']:
        counts[cls] = len([p for p in products if p['classificacao'] == cls])
        print(f"  {cls}: {counts[cls]}")

    html = generate_dashboard_html(products, stats, ids_novos)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding='utf-8')
    print(f"\nDashboard gerado: {args.output}")


if __name__ == '__main__':
    main()
