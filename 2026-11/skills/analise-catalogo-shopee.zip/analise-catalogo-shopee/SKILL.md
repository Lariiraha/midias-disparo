---
name: analise-catalogo-shopee
description: >
  Pesquisa de mercado completa na Shopee a partir de um catálogo de fornecedor (PDF ou planilha),
  com precificação por faixa de comissão e relatório HTML na identidade Desbravando as Vendas.
  Use SEMPRE que a usuária enviar um catálogo/tabela de preços de fornecedor e pedir: análise de
  concorrência, pesquisa de mercado, precificação do catálogo, "analisa esse catálogo",
  "roda a análise do catálogo", /analise-catalogo-shopee, ou variações. Cobre o fluxo inteiro:
  ler catálogo → agrupar famílias → coletar concorrência na Shopee via Chrome → precificar com
  15% de margem → veredicto por família → gerar o dashboard HTML padrão.
---

# Análise de Catálogo x Shopee — Desbravando as Vendas

Fluxo fixo e testado. Siga na ordem, sem pular etapas. O resultado final é SEMPRE um
único arquivo HTML no padrão visual descrito na Etapa 6 (use `assets/gera_html.py` como base).

## Parâmetros fixos (NÃO perguntar)
- **Custo**: coluna AVISTA do catálogo (se houver "à prazo", ignorar). Famílias com variação de
  tamanho/material: registrar faixa de custo e calcular pelo menor.
- **Margem de lucro**: 15%.
- **Agrupamento**: por família de produto (variações de cor = mesma família/mesmo mercado).
- **Comissões Shopee** (escalonadas por faixa de preço final):
  | Faixa do preço final | Comissão | Taxa fixa |
  |---|---|---|
  | Até R$ 79,99 | 20% | R$ 4,00 |
  | R$ 80–99,99 | 14% | R$ 16,00 |
  | R$ 100–199,99 | 14% | R$ 20,00 |
  | R$ 200–499,99 | 14% | R$ 26,00 |
  | Acima de R$ 500 | 14% | R$ 26,00 |
- Frete Grátis/Antecipa/Devolução Fácil/Eventos: FORA do cálculo (citar nas premissas).

## Única pergunta permitida (AskUserQuestion)
Perguntar SOMENTE a alíquota de imposto: opções 8% (padrão desta usuária), 6% (Simples), 0% (MEI),
outra. Se a sessão estiver desassistida, assumir 8% e registrar a premissa. Nada mais de pergunta —
todo o resto usa os padrões acima.

## Etapa 1 — Ler o catálogo e montar as famílias COM critérios de correspondência
Ler o PDF/planilha inteiro (Read com `pages` em PDFs grandes) OLHANDO AS IMAGENS de cada produto,
não só o texto. Consolidar em famílias (juntar cores; juntar materiais só quando o mercado na
Shopee é o mesmo). Para CADA família, registrar os **critérios de match** — os atributos que
definem o produto exato: material (vidro/plástico/inox/tecido...), capacidade/medida (500ml,
28x35cm, aro 24-29...), composição (nº de peças), formato/modelo (ex.: "formato de abacaxi",
não "estampa de abacaxi") e o que se vê na foto do catálogo. Gravar `familias.json`:
`{"familias":[{"id":1,"grupo":"...","nome":"...","cods":"...","custo":58.90,"custo_max":null,
"busca":"palavra-chave shopee","busca_id":"S1",
"match":{"obrigatorio":["vidro","500ml","formato abacaxi"],"proibido":["plástico","caneca","estampa"]}}]}`
A `busca` deve ser específica o bastante para trazer o produto exato (incluir material e medida
quando relevante: "jarra abacaxi vidro 500ml", não só "jarra abacaxi").

## Etapa 2 — Coletar a concorrência na Shopee (Claude in Chrome)
Para CADA busca única (navegador do usuário, ferramenta claude-in-chrome):
1. `navigate` → `https://shopee.com.br/search?keyword={busca urlencoded}`
2. `wait` 7s → `scroll` para baixo (8 ticks) → `wait` 3s (a página só renderiza os cards após scroll)
3. Rodar o extrator de `assets/extrator_shopee.js` em DUAS chamadas de `javascript_tool`
   (a saída trunca ~1300 caracteres — 7 itens por chamada, 14 no total).
Regras aprendidas (IMPORTANTES):
- Agrupar 3 buscas por `browser_batch`; manter os waits — ritmo humano.
- NUNCA usar a API interna `api/v4/search/search_items` em sequência: dispara captcha
  anti-robô. Se aparecer captcha, PARAR, esperar ~20s, voltar à navegação normal; nunca resolver
  captcha — se persistir, pedir para a usuária resolver manualmente.
- **CORRESPONDÊNCIA EXATA (regra crítica)**: comparar SOMENTE anúncios do MESMO produto do
  catálogo. Validar cada item coletado contra os critérios `match` da família:
  1. Filtro por título: descartar itens cujo título contradiga um atributo obrigatório ou
     contenha um proibido (ex.: catálogo = jarra abacaxi de VIDRO 500ml → descartar jarra de
     plástico, caneca com estampa de abacaxi, jarra 1L). Título ambíguo NÃO aprova sozinho.
  2. Conferência VISUAL: tirar `screenshot` da página de resultados (usar `zoom` nos cards em
     dúvida) e comparar as fotos dos anúncios com a foto do catálogo — material, formato,
     tamanho aparente e composição devem bater. Na dúvida, abrir o anúncio.
  3. Meta: mínimo 8 itens VÁLIDOS por família. Se não atingir, refinar a palavra-chave
     (adicionar material/medida/modelo) e buscar de novo; se ainda assim <5 válidos, registrar
     como "nicho raso" (é um achado!) e sinalizar baixa confiança no card.
  Registrar quantos itens foram descartados por não serem o produto exato (vai nas premissas).
- Se a busca retornar outra categoria (ex.: "encosto tunning" → encosto massageador), refazer com
  palavra-chave alternativa.
- **KITS**: NÃO descartar anúncios em kit do mesmo produto — capturar a quantidade de unidades
  lendo o título ("kit 3", "c/ 2", "par", "12 unidades") e gravar no campo `q` de cada item
  (1 = unitário; 0 = kit sem quantidade clara). Kits entram na análise separada da Etapa 3.
- Guardar tudo em `dados_mercado.json`:
  `{"S1":{"kw":"...","it":[{"i":"shopid.itemid","n":"nome","p":68.9,"r":"4.8","q":1}]}}`
- Link de cada anúncio: `https://shopee.com.br/product/{shopid}/{itemid}`.

## Etapa 3 — Precificar UNITÁRIO e KIT separados (usar `assets/analise.py`)
Fórmula iterativa por faixa: `preço = (custo + taxa_fixa) ÷ (1 − comissão − imposto − 0,15)`,
testando cada faixa até o preço cair dentro dela. Guardar comissão R$, taxa fixa, imposto R$ e
lucro R$ por família. Calcular também a margem possível vendendo na MEDIANA do mercado.
**Análise de KIT (sempre fazer, para toda família):**
- Separar o mercado em dois grupos: anúncios unitários (q=1) e kits (q≥2). Estatísticas
  SEPARADAS: preço unitário vs preço POR UNIDADE dos kits (preço ÷ q).
- O veredicto unitário compara só com o mercado unitário; o de kit só com o mercado de kits.
- Simular kits nos tamanhos que EXISTEM no mercado (se não houver, 2/3/6):
  `preço_kit = (q × custo + taxa_fixa) ÷ (1 − comissão − imposto − margem)` — a taxa fixa entra
  UMA vez só, e é aí que kit vira vantagem: unitário barato paga R$ 4,00 por peça (e 20% até
  R$ 79,99); um kit que empurra o preço para faixa de 14% paga a fixa uma vez para q peças.
- Calcular a economia de taxa fixa do melhor kit vs vender q unitários e o "formato recomendado":
  UNITÁRIO E KIT / UNITÁRIO / SÓ EM KIT / UNITÁRIO COM AJUSTES / NENHUM. Um produto NÃO no
  unitário pode ser SIM no kit — esse é um dos insights mais valiosos do relatório.

## Etapa 4 — Veredicto por família (regra fixa)
- **SIM** (verde): preço com 15% ≤ mediana × 1,10.
- **ATENÇÃO** (amarelo neon #ffd400): margem na mediana ≥ 5% OU preço ≤ média (segmento premium).
- **NÃO** (vermelho): para igualar a mediana, margem < 5% ou prejuízo.
Usar a MEDIANA como referência (a média infla com itens premium na busca). Escrever motivo em
texto para cada família (números concretos + observações: nicho raso, marca do fornecedor já
presente na Shopee, produto premium fora do teto do mercado etc.).

## Etapa 5 — Verificação antes de entregar
Refazer os cálculos de forma independente (script de checagem): preço recalculado bate, faixa de
comissão correta para o preço final, custo+taxas+imposto+lucro = preço, min ≤ mediana ≤ máx.
Contar os links no HTML. Renderizar screenshot local (Playwright) e conferir o visual.

## Etapa 6 — Gerar o relatório HTML (usar `assets/gera_html.py`)
Um único arquivo autocontido, nome `pesquisa-mercado-shopee-{fornecedor}-{data}.html`. Identidade
OBRIGATÓRIA (já implementada no script — não inventar outro visual):
- Fundo PRETO; fonte Poppins (Google Fonts); SEM emojis em títulos e textos.
- Roxo SEMPRE em degradê e usado pontualmente: blocos `linear-gradient(135deg,#5e3585,#9b4ede)`,
  textos roxos `linear-gradient(135deg,#b07ce0,#d8b9fa)` (títulos "Visão geral" e "Análise
  detalhada", preços destacados, títulos das premissas).
- Logo Desbravando as Vendas (branco, do site) centralizado no topo, max-height 62px, SEM linha
  divisória abaixo do título: `https://lariiraha.com.br/materiais/uploads/logo-desbravando.png`
- KPIs iniciais: 1º card em degradê roxo; os demais com número colorido (verde/amarelo neon/
  vermelho/laranja) que no hover preenchem o card com a própria cor + texto branco; todos os
  quadradinhos (KPIs, métricas, premissas) PULSAM no hover (animação `pulsar`).
- Seções: KPIs → calculadora interativa de precificação → tabela geral com coluna FORMATO
  (clique rola até a família) → análise detalhada por família em `<details>` (métricas unitário,
  bloco de mercado em KIT por unidade, simulações de kit com veredicto, formato recomendado,
  motivo da decisão, tabela de concorrentes com preço/unidades/avaliação/link "ver anúncio ↗")
  → premissas em cards retangulares individuais (incluir quantos anúncios foram descartados por
  não serem o produto exato) → rodapé "© {ano} Desbravando · Todos os direitos reservados."
  centralizado.
- Veredictos: verde #22c55e / amarelo neon #ffd400 / vermelho #ef4444 (únicos usos dessas cores).

## Etapa 7 — Entregar
Enviar o HTML com SendUserFile (display render) + resumo curto em texto: contagem SIM/ATENÇÃO/NÃO,
principais oportunidades, principais vetos e os 2–3 achados mais importantes (ex.: faixa de
comissão que pune custo médio, fornecedor já vendendo na Shopee). Oferecer aprofundamento.
