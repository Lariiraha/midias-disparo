# Árvore de Diagnóstico — Performance de Produto Shopee

Este documento detalha a lógica de diagnóstico, as causas de cada problema e as ações recomendadas para cada nível do funil.

---

## O Funil de Vendas na Shopee

```
IMPRESSÃO  →  CLIQUE (CTR)  →  VISITA  →  CARRINHO  →  COMPRA
   👁️            📸              👤         🛒           💰
```

Cada etapa é um filtro. O produto precisa "passar" por todas para gerar uma venda. Quando poucos passam de uma etapa para a próxima, ali está o gargalo.

O diagnóstico segue a lógica de "funil": começa pelo topo (impressão) e desce. Se o problema está no topo, não faz sentido analisar as etapas seguintes — primeiro precisa resolver o topo.

---

## NÍVEL 1: PROBLEMA DE IMPRESSÃO

### Critério
Impressões do produto significativamente abaixo da média da conta (menos de 50% da média de impressões de todos os produtos).

### O que está acontecendo
O produto simplesmente não está sendo mostrado para as pessoas. Sem impressão, não existe funil — ninguém vê, ninguém clica, ninguém compra.

### Causas prováveis (verificar nesta ordem)

**1. Penalidades na conta**
- Pontos de penalidade reduzem o alcance de TODOS os produtos da loja
- Se a loja tem penalidades ativas, esse é provavelmente o maior fator
- Verificar: dados coletados na etapa de Desempenho da Loja
- Ação: resolver as penalidades primeiro (completar pedidos, reduzir cancelamentos)

**2. Título do anúncio fraco**
- O título é o principal fator de ranqueamento na busca da Shopee
- Se o título não contém as palavras-chave que os compradores buscam, o produto não aparece
- Ação: pesquisar os termos mais buscados na categoria e reformular o título
- Dica: usar a barra de busca da Shopee e ver as sugestões automáticas — essas são as palavras mais buscadas

**3. Produto sazonal ou fora de tendência**
- Alguns produtos têm demanda cíclica (ex: fantasias em outubro, ventiladores no verão)
- Se o produto é sazonal e está fora do período, baixa impressão é esperada
- Ação: identificar se é sazonal. Se for, não é necessariamente um problema — apenas timing

**4. Categoria muito saturada**
- Se há centenas de vendedores oferecendo o mesmo produto, a visibilidade é dividida
- Produtos sem diferencial tendem a ser "empurrados para baixo" pelo algoritmo
- Ação: revisar se o nicho está saturado e considerar diferenciação

### Recomendações no relatório
```
🔍 DIAGNÓSTICO: Produto com poucas impressões — não está sendo exibido na plataforma

VERIFICAR:
1. Reputação da loja: [X pontos de penalidade / OK]
   → Se tem penalidades: resolver primeiro, pois afeta o alcance de toda a loja
2. Título do anúncio: verificar se contém as palavras-chave corretas
   → Pesquisar na barra de busca da Shopee os termos da categoria
3. Sazonalidade: verificar se o produto tem demanda nesse período

AÇÃO PRINCIPAL: [depende da causa identificada]
```

---

## NÍVEL 2: PROBLEMA DE CTR (abaixo de 1,5%)

### Critério
CTR do produto abaixo de 1,5%. As impressões estão OK (produto é exibido), mas poucas pessoas clicam.

### O que está acontecendo
O produto aparece na busca ou no feed, mas quando a pessoa vê o card (foto + título + preço), ela não se interessa o suficiente para clicar. A primeira impressão visual está falhando.

### O que o comprador vê antes de clicar
Na busca da Shopee, o que aparece é:
- **Foto de capa** (a imagem principal — o fator mais importante)
- Preço
- Título (cortado, aparecem só os primeiros ~40 caracteres)
- Badges (frete grátis, desconto, etc.)
- Avaliação (estrelas)

A foto de capa é responsável por ~70% da decisão de clicar ou não. Se ela não se destaca entre os outros resultados, a pessoa simplesmente rola a tela.

### O que funciona em fotos de capa
- Fundo limpo e claro (branco ou pastel)
- Produto centralizado, bem iluminado
- Ângulo que mostra o produto inteiro
- Badge de desconto ou frete grátis visível
- Contraste com os concorrentes (se todos usam fundo branco, um fundo colorido pode se destacar)

### O que NÃO funciona
- Foto escura ou granulada
- Produto misturado com fundo bagunçado
- Muito texto na imagem (poluição visual)
- Foto genérica do fornecedor/AliExpress sem edição

### Recomendações no relatório
```
📸 DIAGNÓSTICO: Impressões OK, mas CTR baixo ([X]%) — a foto de capa não está atraindo cliques

O produto está sendo exibido, mas quando aparece na busca, a foto/título/preço não
convencem a pessoa a clicar. Como o CTR está abaixo de 1,5%, o foco deve ser na
primeira impressão visual.

AÇÃO PRINCIPAL: Trocar a foto de capa do anúncio
- Usar foto com fundo limpo, boa iluminação, produto centralizado
- Incluir badge de desconto ou frete grátis se aplicável
- Testar diferentes ângulos e ver qual gera mais cliques

IMPACTO ESPERADO: Se o CTR subir de [X]% para 1,5% com as mesmas [Y] impressões,
o produto passaria de [Z] cliques para [W] cliques por mês — [N] cliques a mais
que são [N] oportunidades de venda a mais.
```

---

## NÍVEL 3: PROBLEMA DE OFERTA (baixa adição ao carrinho)

### Critério
Taxa de adição ao carrinho abaixo da média da conta. Impressões e CTR estão OK — as pessoas visitam o anúncio, mas não adicionam ao carrinho.

### O que está acontecendo
A foto de capa atraiu a pessoa (CTR bom), ela clicou e visitou o anúncio. Mas algo na página do produto não convenceu a ponto de adicionar ao carrinho. O problema está na "oferta" — o conjunto de elementos que fazem a pessoa decidir "quero isso".

### O que o comprador avalia na página do produto

**1. Fotos complementares**
- Fotos de diferentes ângulos
- Fotos mostrando o produto em uso
- Fotos com medidas/dimensões
- Vídeo do produto
- Fotos ruins = insegurança sobre a qualidade

**2. Descrição**
- Especificações técnicas claras
- Benefícios (não apenas características)
- Informações de tamanho/cor/material
- Descrição incompleta = dúvida = não compra

**3. Avaliações**
- Nota média e quantidade de avaliações
- Fotos nas avaliações (prova social)
- Avaliações negativas recentes (assustam)
- Pouquíssimas avaliações = desconfiança

**4. Preço**
- Comparação com concorrentes (a Shopee mostra produtos similares)
- Preço "riscado" com desconto funciona melhor
- Preço muito acima da média = desistência

**5. Frete**
- Frete grátis vs frete pago faz diferença enorme
- Prazo de entrega muito longo = desistência
- Frete caro pode custar mais que o produto em itens baratos

### Recomendações no relatório
```
🛒 DIAGNÓSTICO: Impressões e CTR bons, mas taxa de adição ao carrinho baixa ([X]%)
— a oferta não está convencendo quem visita o anúncio

As pessoas se interessam (clicam), visitam a página, mas não adicionam ao carrinho.
Algo na apresentação do produto não está passando confiança ou o custo total
(produto + frete) não está competitivo.

VERIFICAR E AJUSTAR:
1. Fotos complementares: adicionar fotos de uso, medidas, detalhes
2. Descrição: completar especificações, adicionar benefícios
3. Avaliações: verificar se há avaliações negativas afastando compradores
4. Preço: comparar com concorrentes diretos na busca
5. Frete: verificar se o frete grátis está ativado ou se o custo é competitivo

AÇÃO PRINCIPAL: Revisar a página do produto como um todo — a pessoa clica
mas desiste ao ver os detalhes.
```

---

## NÍVEL 4: PROBLEMA DE URGÊNCIA (baixa conversão de venda)

### Critério
Taxa de conversão de pedido pago abaixo da média da conta. Impressões, CTR e adição ao carrinho estão OK — mas a pessoa não finaliza a compra.

### O que está acontecendo
A pessoa viu o produto, clicou, visitou, gostou o suficiente para adicionar ao carrinho... mas não comprou. Isso é o cenário clássico de "depois eu compro" — ela adicionou ao carrinho e esqueceu, ou está comparando com outro vendedor, ou simplesmente não sentiu urgência para comprar agora.

### Por que as pessoas abandonam o carrinho
- **"Depois eu compro"**: sem urgência, a compra é adiada indefinidamente
- **Comparando preços**: adicionou no carrinho de vários vendedores e vai comprar do mais barato
- **Esperando promoção**: sabe que a Shopee tem promoções frequentes
- **Frete/prazo**: na hora de finalizar, o frete ou prazo desanima
- **Forma de pagamento**: não tem o cartão na hora ou prefere Pix

### Estratégias de urgência

**1. Cupons de desconto agressivos com prazo curto**
- Criar cupom de desconto com validade de 24-48 horas
- O desconto precisa ser relevante (mínimo 5-10% ou valor fixo significativo)
- Prazo curto é o que cria urgência — "se não usar agora, perde"
- Comunicar via chat da Shopee ou pela vitrine

**2. Transmissão por chat de carrinho abandonado**
- A Shopee permite enviar mensagens para clientes que adicionaram ao carrinho mas não compraram
- Frequência ideal: 1x por semana
- Conteúdo: lembrete + cupom exclusivo
- Verificar se a funcionalidade está disponível na conta (nem todas têm)
- Caminho no Seller Center: Central de Marketing → Chat de Marketing → Transmissão

**3. Promoções relâmpago**
- Colocar o produto em promoção por tempo limitado
- A contagem regressiva cria urgência visual
- Funciona especialmente bem se o produto já tem adição ao carrinho alta

### Recomendações no relatório
```
⏰ DIAGNÓSTICO: Funil funcionando até o carrinho, mas conversão de venda baixa ([X]%)
— as pessoas adicionam ao carrinho mas não finalizam a compra

O anúncio está bom (atrai clique, convence a adicionar ao carrinho), mas falta o
empurrão final. A pessoa pensa "depois eu compro" e esquece.

AÇÕES PRINCIPAIS:
1. Criar cupons de desconto com prazo curto (24-48h)
   → Desconto relevante (5-10% ou valor fixo)
   → A urgência do prazo curto é o que converte

2. Transmissão por chat de carrinho abandonado (1x por semana)
   → Se disponível na conta: Central de Marketing → Chat de Marketing
   → Enviar lembrete + cupom exclusivo para quem abandonou o carrinho

3. Considerar promoção relâmpago para criar urgência visual
   → Contagem regressiva incentiva compra imediata

NOTA: O problema NÃO é no anúncio em si — é na falta de urgência.
O foco é em incentivos de tempo limitado, não em mudar fotos ou descrição.
```

---

## PRODUTO SAUDÁVEL

### Critério
Passou por todos os níveis sem cair em nenhum problema. Impressões acima de 50% da média, CTR acima de 1,5%, taxa de carrinho acima da média, taxa de conversão acima da média.

### O que significa
O funil está funcionando. Não quer dizer que o produto é perfeito — mas as etapas estão fluindo. O foco aqui não é corrigir, é escalar.

### Recomendações
```
✅ PRODUTO SAUDÁVEL — Funil funcionando

O anúncio está passando por todas as etapas do funil sem gargalos significativos.

FOCO: Escalar
- Considerar investir em Shopee Ads para amplificar o que já funciona
- Garantir estoque suficiente para atender demanda crescente
- Manter monitoramento — o que funciona hoje pode mudar
```

---

## Cálculos de Impacto

Para tornar o diagnóstico mais tangível, incluir simulações de impacto quando possível:

### Para CTR
```
Impressões atuais: [X]
CTR atual: [Y]%
Cliques atuais: X × Y/100 = [Z]

Se CTR subisse para 1,5%:
Novos cliques: X × 1,5/100 = [W]
Diferença: W - Z = [N] cliques a mais
Com taxa de conversão de [C]%: N × C/100 = [V] vendas a mais potenciais
```

### Para Adição ao Carrinho
```
Visitantes atuais: [X]
Taxa carrinho atual: [Y]%
Adições atuais: X × Y/100 = [Z]

Se taxa subisse para a média ([M]%):
Novas adições: X × M/100 = [W]
Diferença: W - Z = [N] adições a mais
```

### Para Conversão de Venda
```
Adições ao carrinho atuais: [X]
Taxa conversão atual: [Y]%
Vendas atuais: [Z]

Se taxa subisse para a média ([M]%):
Novas vendas: X × M/100 = [W]
Diferença: W - Z = [N] vendas a mais
```
