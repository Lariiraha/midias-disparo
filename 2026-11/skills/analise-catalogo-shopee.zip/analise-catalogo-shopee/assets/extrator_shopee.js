// Extrator de resultados de busca da Shopee (rodar via javascript_tool no Claude in Chrome)
// Pré-requisito: navegar para https://shopee.com.br/search?keyword=... , esperar ~7s, scroll para baixo, esperar ~3s.
// CHAMADA 1 (extrai e devolve os 7 primeiros):
const as=[...document.querySelectorAll('a')].filter(a=>/-i\.\d+\.\d+/.test(a.href));
window.__D=as.slice(0,14).map(a=>{
  const t=a.innerText||'';
  const m=a.href.match(/-i\.(\d+)\.(\d+)/);
  const ps=[...t.matchAll(/R\$\s*([\d.,]+)/g)].map(x=>parseFloat(x[1].replace(/\./g,'').replace(',','.')));
  const sd=(t.match(/([\d.,]+\s*(?:mil|k)?\+?)\s*(?:vendid|sold)/i)||[])[1]||'';
  const rt=(t.match(/\n([0-5]\.\d)\n/)||[])[1]||'';
  return {i:m[1]+'.'+m[2], n:t.split('\n')[0].trim().slice(0,34), p:ps[0]??null, s:sd, r:rt}
});
JSON.stringify({q:'IDBUSCA',c:window.__D.length,it:window.__D.slice(0,7)})
// CHAMADA 2 (restante — a saída da ferramenta trunca ~1300 caracteres, por isso 2 chamadas):
// JSON.stringify({q:'IDBUSCAb',it:window.__D.slice(7)})
// Link do anúncio: https://shopee.com.br/product/{shopid}/{itemid}  (i = "shopid.itemid")
