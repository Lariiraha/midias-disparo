# -*- coding: utf-8 -*-
"""Análise de mercado Shopee x catálogo — precificação com margem alvo, imposto e comissões.
v2: separa mercado UNITÁRIO x KIT e simula precificação em kit (taxa fixa cobrada 1x por pedido).
Espera: familias.json (coleta já validada por correspondência exata) e dados_mercado.json.
Cada item pode ter "q": unidades do anúncio (1 = unitário; 2+ = kit; ausente = deduzir do título).
"""
import json, statistics, re

fam = json.load(open('familias.json'))['familias']
mkt = json.load(open('dados_mercado.json'))

# id da família -> chave da busca (definir "busca_id" em familias.json, ex.: "S1")
MAP = {f['id']: f['busca_id'] for f in fam}

MARGEM  = 0.15
IMPOSTO = 0.08   # sobrescrever com a resposta da usuária
FAIXAS = [(0,79.99,0.20,4.0),(80,99.99,0.14,16.0),(100,199.99,0.14,20.0),(200,499.99,0.14,26.0),(500,10**9,0.14,26.0)]

KIT_RE = re.compile(r'\b(?:kit|jogo|par)\b|\b\d{1,3}\s*(?:un\b|und|unid|unidades|pe[cç]as|p[cç]s)\b|c/\s*\d', re.I)

def qty_do_titulo(nome):
    """Unidades a partir do título: 1 = unitário; 0 = kit sem quantidade clara (excluir do por-unidade)."""
    if not KIT_RE.search(nome or ''): return 1
    for n in re.findall(r'\b(\d{1,3})\b', nome):
        if 2 <= int(n) <= 50: return int(n)
    if re.search(r'\bpar\b', nome, re.I): return 2
    return 0

def precifica(custo):
    for lo,hi,com,fixa in FAIXAS:
        tot = com+IMPOSTO+MARGEM
        if tot>=1: continue
        p = (custo+fixa)/(1-tot)
        if lo<=p<=hi or (lo==500 and p>=500):
            return {'preco':p,'com':com,'fixa':fixa,'taxa_shopee':p*com+fixa,'imposto':p*IMPOSTO,'lucro':p*MARGEM}
    best=None
    for lo,hi,com,fixa in FAIXAS:
        p=(custo+fixa)/(1-(com+IMPOSTO+MARGEM))
        d=0 if lo<=p<=hi else min(abs(p-lo),abs(p-hi))
        if best is None or d<best[0]: best=(d,p,com,fixa)
    _,p,com,fixa=best
    return {'preco':p,'com':com,'fixa':fixa,'taxa_shopee':p*com+fixa,'imposto':p*IMPOSTO,'lucro':p*MARGEM}

def margem_no_preco(custo, preco):
    for lo,hi,com,fixa in FAIXAS:
        if lo<=preco<=hi or (lo==500 and preco>=500):
            return 1 - (custo+fixa)/preco - com - IMPOSTO
    return None

def stats(ps):
    return {'n':len(ps),'min':min(ps),'max':max(ps),'avg':sum(ps)/len(ps),'med':statistics.median(ps)} if ps else None

def veredicto(preco, st, custo):
    if st is None: return 'SEM DADOS','amarelo',None
    mm = margem_no_preco(custo, st['med'])
    if preco <= st['med']*1.10: return 'SIM','verde',mm
    if (mm is not None and mm >= 0.05) or preco <= st['avg']: return 'ATENÇÃO','amarelo',mm
    return 'NÃO','vermelho',mm

out=[]
for f in fam:
    s = mkt[MAP[f['id']]]
    items=[]
    for x in s['it']:
        if not x.get('p'): continue
        q = x.get('q', qty_do_titulo(x.get('n','')))
        items.append({**x,'q':q})
    unit = [x for x in items if x['q']==1]
    kits = [x for x in items if x['q']>=2]
    st_u = stats([x['p'] for x in unit])
    st_k_un = stats([x['p']/x['q'] for x in kits])          # preço POR UNIDADE dos kits
    # --- unitário ---
    pr = precifica(f['custo'])
    verdict, cor, mm = veredicto(pr['preco'], st_u, f['custo'])
    # --- kits: simular os tamanhos observados no mercado (ou 2/3/6 se não houver) ---
    tamanhos = sorted({x['q'] for x in kits}) or [2,3,6]
    sims=[]
    for q in tamanhos[:5]:
        pk = precifica(f['custo']*q)
        por_un = pk['preco']/q
        if st_k_un: v_k = 'SIM' if por_un <= st_k_un['med']*1.10 else ('ATENÇÃO' if por_un<=st_k_un['avg'] else 'NÃO')
        else: v_k='SEM DADOS'
        sims.append({'q':q,'preco':pk['preco'],'por_un':por_un,'lucro':pk['lucro'],
                     'fixa':pk['fixa'],'com':pk['com'],'verdict':v_k})
    melhor_kit = next((k for k in sims if k['verdict']=='SIM'), None)
    economia = (melhor_kit['q']*pr['fixa'] - melhor_kit['fixa']) if melhor_kit else None
    if verdict=='SIM' and melhor_kit: formato='UNITÁRIO E KIT'
    elif verdict=='SIM': formato='UNITÁRIO'
    elif melhor_kit: formato='SÓ EM KIT'
    elif verdict=='ATENÇÃO': formato='UNITÁRIO COM AJUSTES'
    else: formato='NENHUM'
    out.append({'fam':f,'busca':s['kw'],
        'stats':st_u or stats([x['p'] for x in items]),
        'stats_kit_un':st_k_un,'n_kits':len(kits),'n_unit':len(unit),
        'calc':pr,'calc_max':precifica(f['custo_max']) if f.get('custo_max') else None,
        'margem_na_mediana':mm,
        'pct_vs_media':(pr['preco']/st_u['avg']-1) if st_u else 0,
        'verdict':verdict,'cor':cor,'sims_kit':sims,'melhor_kit':melhor_kit,
        'economia_taxa_fixa':economia,'formato':formato,
        'top':sorted(items,key=lambda x:x['p'])[:14]})

json.dump(out, open('resultado.json','w'), ensure_ascii=False, indent=1)
for o in out:
    mk = f" | melhor kit: {o['melhor_kit']['q']}un a {o['melhor_kit']['por_un']:.2f}/un" if o['melhor_kit'] else ''
    print(f"{o['fam']['id']:>3} {o['fam']['nome'][:44]:<44} unit={o['verdict']:<9} formato={o['formato']}{mk}")
