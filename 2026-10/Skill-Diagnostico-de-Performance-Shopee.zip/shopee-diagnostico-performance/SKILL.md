---
name: shopee-diagnostico-performance
description: |
  Diagnóstico de performance de produtos Shopee via Claude in Chrome — coleta no Seller Center + análise de funil + plano de ação por anúncio.
  Use SEMPRE que o usuário mencionar: diagnóstico de performance Shopee, funil de vendas, "por que não vendo?", CTR baixo, impressão baixa, carrinho abandonado, "clicam mas não compram", "ninguém adiciona ao carrinho", gargalo de vendas, análise de impressão/CTR/conversão, coletar dados de performance no Seller Center, "meu produto não aparece", penalidades afetando vendas, qualquer combinação de Shopee + performance + diagnóstico + funil + CTR + conversão + carrinho.
  Acione mesmo para "analisa a performance dos meus produtos" ou "por que não tô vendendo?" se o contexto indicar Shopee.
---

# Shopee Diagnóstico de Performance — Análise de Funil por Produto

Você é um especialista em otimização de anúncios na Shopee. Seu trabalho é entrar no Seller Center via Claude in Chrome, coletar os dados de performance de TODOS os produtos, identificar em qual etapa do funil cada anúncio está travando (impressão → clique → carrinho → compra), e entregar um relatório completo com diagnóstico e plano de ação individualizado por ID.

## A LÓGICA DO FUNIL

Cada venda na Shopee passa por etapas. Quando um produto não vende, o problema está em uma etapa específica — e a solução depende de ONDE o funil quebra. Não adianta trocar foto se o problema é frete caro. Não adianta mexer no preço se ninguém está vendo o anúncio.

O funil é:

```
IMPRESSÃO → CLIQUE (CTR) → VISITA → CARRINHO → COMPRA (PEDIDO)
```

Cada etapa tem causas e soluções diferentes. A skill diagnostica exatamente onde cada produto está travando.

---

## FLUXO COMPLETO

```
1. Abrir Seller Center via Claude in Chrome
2. Navegar até: Informações Gerenciais → Produto → Performance do Produto
3. Configurar período: Últimos 30 dias (pedido pago)
4. Coletar dados de 100% dos produtos (todas as páginas)
5. Navegar até: Desempenho da Loja → verificar reputação e penalidades
6. Analisar cada produto pela árvore de diagnóstico
7. Gerar relatório HTML interativo com diagnóstico + plano de ação
8. Entregar ao usuário
```

---

## ETAPA 1 — COLETA VIA CLAUDE IN CHROME

### 1.0 Preparar ambiente

```
1. tabs_context_mcp(createIfEmpty: true) → anotar tabId
2. navigate(tabId, "https://seller.shopee.com.br")
3. computer(action: "wait", tabId, duration: 3)
4. computer(action: "screenshot", tabId)
   → Se tela de LOGIN: avisar "Preciso que você faça login no Seller Center primeiro. Me avise quando estiver logado."
   → Se painel visível: continuar
```

### 1.1 Navegar até Performance do Produto

```
1. find(tabId, "Informações Gerenciais") no menu lateral → clicar
2. computer(action: "wait", tabId, duration: 2)
3. find(tabId, "Produto") dentro do submenu → clicar
   → Se não encontrar submenu "Produto", tentar:
     find(tabId, "Performance do Produto") ou
     find(tabId, "Produtos") dentro de Informações Gerenciais
4. computer(action: "wait", tabId, duration: 3)
5. screenshot → verificar se está na página de Performance do Produto
```

### 1.2 Configurar período

```
1. Procurar seletor de período (geralmente no topo direito)
   → find(tabId, "30 dias") ou find(tabId, "período") ou find(tabId, "Últimos 30 dias")
2. Selecionar "Últimos 30 dias" com base em "Pedido pago"
3. computer(action: "wait", tabId, duration: 3)
4. screenshot → confirmar período configurado
```

### 1.3 Coletar dados de TODOS os produtos

As métricas que precisamos de cada produto:

| Métrica | O que é |
|---|---|
| ID do Item | Identificador único (usar este, NÃO o nome) |
| Impressão do Produto | Quantas vezes foi exibido na plataforma |
| CTR (%) | Taxa de clique — quem viu e clicou |
| Visitantes do Produto | Pessoas únicas que visitaram o anúncio |
| Visitantes que Adicionaram ao Carrinho | Quem visitou e colocou no carrinho |
| Taxa de Conversão (adicionar ao carrinho) | % dos visitantes que adicionaram ao carrinho |
| Pedidos (Pedido Pago) | Vendas efetivadas |

```
1. get_page_text(tabId) → extrair tabela de produtos

2. Se a tabela for grande, usar JavaScript para extração limpa:
   javascript_tool(tabId, action: "javascript_exec", text: `
     const rows = document.querySelectorAll('table tbody tr');
     const data = [];
     rows.forEach(row => {
       const cells = row.querySelectorAll('td');
       data.push(Array.from(cells).map(c => c.textContent.trim()));
     });
     JSON.stringify(data);
   `)

3. PAGINAÇÃO — ler TODAS as páginas:
   → find(tabId, "Próxima") ou find(tabId, "próxima página") ou find(tabId, ">")
   → Repetir leitura até coletar 100% dos produtos
   → Contar total de produtos coletados vs total indicado na página

4. Considerar APENAS linhas de produto-pai (impressão com valor numérico, não "-")
```

O parse de números deve respeitar o formato brasileiro: "1.234" = 1234, "2,39%" = 2.39%.

### 1.4 Coletar reputação e penalidades da loja

Essa etapa é necessária para o diagnóstico de produtos com poucas impressões — penalidades afetam diretamente o alcance orgânico.

```
1. find(tabId, "Desempenho da Loja") ou find(tabId, "Saúde da Loja") no menu lateral
   → clicar
2. computer(action: "wait", tabId, duration: 3)
3. screenshot
4. get_page_text(tabId) → extrair:

   PENALIDADES:
   - Pontos de penalidade: número
   - Status da loja (Excelente / Bom / Precisa Melhorar)

   TAXAS:
   - Taxa de não cumprimento: %
   - Taxa de cancelamento: %
   - Taxa de envio atrasado: %

   AVALIAÇÕES:
   - Nota média da loja
   - Avaliações negativas recentes

5. Guardar dados de reputação para usar no diagnóstico
```

---

## ETAPA 2 — CÁLCULOS E CLASSIFICAÇÃO

### 2.1 Calcular médias da conta

Com todos os produtos coletados, calcular referências:

```
Média de Impressões = soma de todas impressões ÷ número de produtos
Mediana de Impressões = valor do meio quando ordenados
CTR médio = soma de todos os CTRs ÷ número de produtos
Taxa média de adição ao carrinho = soma ÷ número de produtos
Taxa média de conversão de pedido = soma ÷ número de produtos
```

### 2.2 Classificar cada produto no funil

Para CADA produto (identificado por ID), aplicar a árvore de diagnóstico na ordem:

**NÍVEL 1 — Impressões** (o produto está sendo visto?)

O produto tem impressões significativamente abaixo da média da conta (menos de 50% da média)?

→ **SIM**: Classificar como **PROBLEMA DE IMPRESSÃO**
  - Verificar se a loja tem pontos de penalidade (dados coletados na etapa 1.4)
  - Se tem penalidades: a causa provável é a penalização da conta reduzindo alcance
  - Se reputação OK: o problema está no título (não ranqueia nas buscas) ou o item é sazonal/fora de tendência

→ **NÃO** (impressões OK): ir para Nível 2

**NÍVEL 2 — CTR** (as pessoas clicam?)

O CTR do produto está abaixo de 1,5%?

→ **SIM**: Classificar como **PROBLEMA DE CTR**
  - Causa: a foto de capa não atrai clique. Quando o produto aparece na busca/feed, a primeira impressão visual não convence a pessoa a clicar.
  - Ação: trocar a foto principal do anúncio

→ **NÃO** (CTR OK, acima de 1,5%): ir para Nível 3

**NÍVEL 3 — Adição ao Carrinho** (a oferta convence?)

A taxa de adição ao carrinho está abaixo da média da conta?

→ **SIM**: Classificar como **PROBLEMA DE OFERTA**
  - Causa: a pessoa clicou (se interessou pela foto), visitou o anúncio, mas não adicionou ao carrinho. Algo na página do produto não convenceu.
  - Verificar: fotos complementares fracas, descrição ruim, avaliações negativas, preço alto em relação à concorrência, frete caro

→ **NÃO** (adição ao carrinho OK): ir para Nível 4

**NÍVEL 4 — Conversão de Venda** (finalizam a compra?)

A taxa de conversão de pedido pago está abaixo da média da conta?

→ **SIM**: Classificar como **PROBLEMA DE URGÊNCIA**
  - Causa: a pessoa adicionou ao carrinho mas não finalizou a compra. Falta gatilho de urgência — ela pensa "depois eu compro" e esquece.
  - Ação: cupons de desconto agressivos com prazo curto (24-48h), transmissão por chat de carrinho abandonado 1x por semana (se disponível na conta)

→ **NÃO**: Classificar como **SAUDÁVEL** — o funil está funcionando bem

### 2.3 Resumo das classificações

| Classificação | Cor | Ícone | Significado |
|---|---|---|---|
| PROBLEMA DE IMPRESSÃO | Roxo | 👁️ | Ninguém vê o produto |
| PROBLEMA DE CTR | Vermelho | 📸 | Veem mas não clicam |
| PROBLEMA DE OFERTA | Laranja | 🛒 | Clicam mas não adicionam ao carrinho |
| PROBLEMA DE URGÊNCIA | Amarelo | ⏰ | Adicionam mas não compram |
| SAUDÁVEL | Verde | ✅ | Funil funcionando |

---

## ETAPA 3 — GERAR RELATÓRIO HTML

O resultado final é um arquivo HTML completo e interativo, salvo na pasta de outputs. O relatório usa o ID do produto (não o nome) para identificação — o vendedor pode buscar pelo ID diretamente no Seller Center.

### Estrutura do Dashboard

#### Seção 1: Resumo Executivo
- Total de produtos analisados
- Médias da conta (impressões, CTR, taxa carrinho, taxa conversão)
- Distribuição por classificação (quantos em cada nível do funil)
- Status da reputação da loja (pontos de penalidade, nota)
- Cards coloridos com os números principais

#### Seção 2: Visão do Funil
- Gráfico visual do funil mostrando onde os produtos estão travando
- Barra horizontal ou funil mostrando a distribuição: quantos param em cada etapa

#### Seção 3: Diagnóstico por Grupo

Para cada grupo (Impressão, CTR, Oferta, Urgência), um bloco com:

**Header colorido com ícone + nome do problema + quantidade de produtos**

**Card explicativo:**
- O QUE ESTÁ ACONTECENDO: explicação em linguagem simples
- POR QUE ISSO ACONTECE: causas prováveis
- O QUE FAZER: ações específicas e práticas

**Tabela dos produtos nesse grupo:**
- ID do Item
- Impressões
- CTR (%)
- Visitantes
- Adição ao Carrinho (%)
- Pedidos
- Indicadores visuais (vermelho/verde) em cada métrica

**Para PROBLEMA DE IMPRESSÃO especificamente:**
- Incluir alerta sobre reputação da loja se houver penalidades
- Listar pontos de penalidade encontrados
- Sugerir verificar se o item é sazonal

**Para PROBLEMA DE URGÊNCIA especificamente:**
- Incluir instruções práticas de como criar cupons com prazo curto
- Mencionar a transmissão por chat de carrinho abandonado (se a conta tiver essa funcionalidade)

#### Seção 4: Produtos Saudáveis
- Tabela com os produtos que passaram por todo o funil
- Nota: "Esses produtos estão com o funil funcionando. Foco em escalar (ads, estoque)."

#### Seção 5: Tabela Completa
- TODOS os produtos em uma tabela única
- Filtros por classificação (Impressão, CTR, Oferta, Urgência, Saudável)
- Ordenação por qualquer coluna clicando no header
- Busca por ID
- Cor de fundo da linha conforme classificação
- Coluna "Diagnóstico" com o nome do problema
- Coluna "Ação Principal" com a recomendação resumida

#### Seção 6: Status da Loja
- Reputação: pontos de penalidade
- Nota média de avaliações
- Taxas operacionais (cancelamento, atraso)
- Alerta se alguma taxa está impactando o alcance

### Estilo Visual

- **Fundo escuro** (dark mode) — #1a1a2e, #16213e, #0f3460
- **Cards com bordas arredondadas** e sombra suave
- **Cores por classificação**: roxo (#9b59b6) impressão, vermelho (#e74c3c) CTR, laranja (#e17055) oferta, amarelo (#f39c12) urgência, verde (#00b894) saudável
- **Fonte**: system-ui
- **Responsivo**: funciona em desktop e mobile
- **Tabela com hover e ordenação** clicando nos headers
- **Filtros rápidos** por classificação
- **Barra de busca** por ID
- **Funil visual** com CSS (barras horizontais proporcionais ou formato de funil)
- **Cards expansíveis** `<details>/<summary>` para diagnóstico detalhado

### Implementação

Gerar um único arquivo HTML com CSS e JS embutidos:
1. Dados via objeto JS no topo (`const PERFORMANCE_DATA = [...]`, `const LOJA_DATA = {...}`)
2. Renderização dinâmica da tabela e cards
3. Ordenação da tabela por qualquer coluna
4. Filtros rápidos por classificação
5. Busca por ID
6. Funil visual com proporções reais
7. Salvar em `/sessions/eloquent-intelligent-gauss/mnt/outputs/shopee-diagnostico-performance.html`

---

## FLUXO RESUMIDO

```
1. Claude in Chrome → abrir Seller Center
2. Informações Gerenciais → Produto → Performance do Produto (30 dias, pedido pago)
3. Coletar dados de 100% dos produtos (todas as páginas, apenas produto-pai)
4. Desempenho da Loja → coletar reputação e penalidades
5. Para cada produto (por ID), aplicar árvore de diagnóstico:
   a. Impressão baixa? → Problema de Impressão (verificar penalidades, título, sazonalidade)
   b. CTR < 1,5%? → Problema de CTR (trocar foto principal)
   c. Taxa carrinho baixa? → Problema de Oferta (fotos, descrição, avaliações, preço, frete)
   d. Conversão venda baixa? → Problema de Urgência (cupons agressivos, chat carrinho abandonado)
   e. Tudo OK? → Saudável
6. Gerar dashboard HTML interativo
7. Entregar ao usuário
```

---

## ERROS COMUNS A EVITAR

- **Não usar nome do produto.** Identificar SEMPRE por ID do Item. O vendedor localiza o produto pelo ID no Seller Center.
- **Não processar variações.** Apenas linhas de produto-pai (impressão com valor numérico).
- **Não pular páginas.** Coletar 100% dos produtos — navegar por TODAS as páginas da tabela.
- **Não esquecer a reputação.** Os dados de penalidade são essenciais para o diagnóstico de impressão baixa.
- **Não dar recomendações genéricas.** Cada nível do funil tem ação específica e diferente.
- **Não inventar dados.** Se alguma métrica não estiver disponível, informar ao usuário.
- **Parse correto de números brasileiros.** "1.234" = 1234, "2,39%" = 2.39.
- **Não confundir taxa de adição ao carrinho com taxa de conversão de pedido.** São etapas diferentes do funil com diagnósticos diferentes.
