# -*- coding: utf-8 -*-
"""Gera o dashboard HTML final da pesquisa de mercado Dricar x Shopee."""
import json
from datetime import date

R = json.load(open('resultado.json'))
HOJE = 'DD/MM/AAAA'          # data da análise
FORN = 'NOME DO FORNECEDOR'  # ex.: 'Catálogo Dricar 2026'
IMPOSTO_PCT = '8'            # alíquota respondida pela usuária

def brl(v): return ('R$ '+f'{v:,.2f}').replace(',','X').replace('.',',').replace('X','.')
def pct(v): return f'{v*100:+.0f}%'.replace('-','−')

CORES = {'verde':('#22c55e','SIM — dá para concorrer'),
         'amarelo':('#ffd400','ATENÇÃO — só com ajustes'),
         'vermelho':('#ef4444','NÃO — fora de preço')}

NOTAS = {}  # observações por família: {id: 'texto'} — nicho raso, marca do fornecedor na Shopee etc.

def motivo(o):
    f,st,c=o['fam'],o['stats'],o['calc']
    p=c['preco']; med=st['med']; mm=o['margem_na_mediana']
    m=[]
    if o['verdict']=='SIM':
        m.append(f"Com 15% de margem o preço sai a {brl(p)}, {'abaixo' if p<med else 'na faixa'} da mediana do mercado ({brl(med)}) — você entra competitivo sem sacrificar lucro.")
        if p<st['min']: m.append(f"Seu preço ficaria ABAIXO do concorrente mais barato ({brl(st['min'])}) — há espaço para aumentar a margem acima de 15%.")
        elif mm and mm>0.15: m.append(f"Mesmo vendendo na mediana do mercado, a margem chegaria a {mm*100:.0f}%.")
    elif o['verdict']=='ATENÇÃO':
        m.append(f"Com 15% de margem ({brl(p)}) você fica {pct(p/med-1)} vs a mediana ({brl(med)}).")
        if mm is not None and mm>=0.05: m.append(f"Para igualar a mediana do mercado a margem cai para ~{mm*100:.0f}% — viável, mas apertado.")
        else: m.append(f"Só compete no segmento premium da busca (média {brl(st['avg'])}), com anúncio muito bem trabalhado.")
    else:
        m.append(f"Preço com 15% de margem ({brl(p)}) fica {pct(p/med-1)} acima da mediana do mercado ({brl(med)}).")
        if mm is not None:
            m.append(f"Para vender no preço mediano do mercado a margem seria de {mm*100:.0f}% — {'prejuízo' if mm<0 else 'abaixo do mínimo saudável'}. O custo do fornecedor não permite competir.")
    mk=o.get('melhor_kit')
    if mk and o['verdict']!='SIM':
        m.append(f"PORÉM em formato KIT o jogo muda: vendendo kit de {mk['q']} un a {brl(mk['preco'])} ({brl(mk['por_un'])}/un), a taxa fixa é paga uma vez só e o preço por unidade fica competitivo no mercado de kits — {'economia de '+brl(o['economia_taxa_fixa'])+' em taxa fixa vs vender '+str(mk['q'])+' unitários' if o.get('economia_taxa_fixa') else 'formato recomendado'}.")
    elif mk:
        m.append(f"Além do unitário, o kit de {mk['q']} un ({brl(mk['por_un'])}/un) também compete — a taxa fixa única dilui o custo por peça.")
    if o['fam']['id'] in NOTAS: m.append(NOTAS[o['fam']['id']])
    return ' '.join(m)

# ---------- HTML ----------
tot_ads = sum(o['stats']['n'] for o in R)
n_sim = sum(1 for o in R if o['verdict']=='SIM')
n_at  = sum(1 for o in R if o['verdict']=='ATENÇÃO')
n_nao = sum(1 for o in R if o['verdict']=='NÃO')

rows=''
for o in R:
    f,st,c=o['fam'],o['stats'],o['calc']
    cor,_=CORES[o['cor']]
    custo_txt = brl(f['custo']) + (f" – {brl(f['custo_max'])}" if f.get('custo_max') else '')
    rows+=f'''<tr onclick="document.getElementById('fam{f['id']}').scrollIntoView({{behavior:'smooth'}})">
<td class="mono">{f['id']}</td><td>{f['nome']}</td><td class="mono">{custo_txt}</td>
<td class="mono destaque">{brl(c['preco'])}</td>
<td class="mono">{brl(st['min'])}</td><td class="mono">{brl(st['med'])}</td><td class="mono">{brl(st['avg'])}</td><td class="mono">{brl(st['max'])}</td>
<td class="mono">{st['n']}</td>
<td style="font-size:11.5px">{o.get('formato','')}</td>
<td><span class="badge" style="background:{cor}22;color:{cor};border:1px solid {cor}55">{o['verdict']}</span></td></tr>'''

cards=''
for o in R:
    f,st,c=o['fam'],o['stats'],o['calc']
    cor,rotulo=CORES[o['cor']]
    linhas=''
    for it in o['top']:
        url=f"https://shopee.com.br/product/{it['i'].split('.')[0]}/{it['i'].split('.')[1]}"
        nota=it.get('r') or '–'
        qv=it.get('q',1); qtxt=f'kit {qv}' if qv and qv>1 else ('kit ?' if qv==0 else '1')
        linhas+=f'<tr><td>{it["n"]}</td><td class="mono">{brl(it["p"])}</td><td class="mono">{qtxt}</td><td class="mono">{nota}</td><td><a href="{url}" target="_blank">ver anúncio ↗</a></td></tr>'
    mm=o['margem_na_mediana']
    mm_txt=f"{mm*100:.0f}%" if mm is not None else 'n/a'
    # bloco de kits
    kit_html=''
    if o.get('n_kits'):
        sk=o.get('stats_kit_un')
        kit_html+=f'<div><span>Mercado em KIT — preço por unidade ({o["n_kits"]} anúncios)</span><b class="mono">{brl(sk["min"])} / {brl(sk["med"])} / {brl(sk["avg"])} / {brl(sk["max"])}</b></div>' if sk else ''
    for sim in o.get('sims_kit',[]):
        if sim['verdict']=='SEM DADOS': continue
        kit_html+=f'<div><span>Simulação KIT {sim["q"]} un (taxa fixa 1x)</span><b class="mono">{brl(sim["preco"])} → {brl(sim["por_un"])}/un · lucro {brl(sim["lucro"])} · {sim["verdict"]}</b></div>'
    if o.get('formato'):
        kit_html+=f'<div><span>Formato recomendado</span><b class="mono destaque">{o["formato"]}</b></div>'
    cmax = f'<div><span>Preço (custo maior da família)</span><b class="mono">{brl(o["calc_max"]["preco"])}</b></div>' if o.get('calc_max') else ''
    cards+=f'''
<details class="fam" id="fam{f['id']}">
<summary><span class="vbar" style="background:{cor}"></span>
<span class="ftit">{f['id']}. {f['nome']}</span>
<span class="badge" style="background:{cor}22;color:{cor};border:1px solid {cor}55">{rotulo}</span></summary>
<div class="fbody">
<div class="grid">
<div><span>Custo fornecedor (à vista)</span><b class="mono">{brl(f['custo'])}{(' – '+brl(f['custo_max'])) if f.get('custo_max') else ''}</b></div>
<div><span>Preço sugerido (15% margem)</span><b class="mono destaque">{brl(c['preco'])}</b></div>
{cmax}
<div><span>Comissão aplicada</span><b class="mono">{c['com']*100:.0f}% + {brl(c['fixa'])} = {brl(c['taxa_shopee'])}</b></div>
<div><span>Imposto ({IMPOSTO_PCT}%)</span><b class="mono">{brl(c['imposto'])}</b></div>
<div><span>Lucro líquido por venda</span><b class="mono" style="color:#4ade80">{brl(c['lucro'])}</b></div>
<div><span>Mercado (menor / mediana / média / maior)</span><b class="mono">{brl(st['min'])} / {brl(st['med'])} / {brl(st['avg'])} / {brl(st['max'])}</b></div>
<div><span>Concorrentes analisados</span><b class="mono">{st['n']} (busca: “{o['busca']}”)</b></div>
<div><span>Posição vs média</span><b class="mono">{pct(o['pct_vs_media'])}</b></div>
<div><span>Margem se vender na mediana</span><b class="mono">{mm_txt}</b></div>
{kit_html}
</div>
<p class="motivo"><b>Decisão:</b> {motivo(o)}</p>
<table class="conc"><thead><tr><th>Concorrente</th><th>Preço</th><th>Un.</th><th>Avaliação</th><th>Link</th></tr></thead><tbody>{linhas}</tbody></table>
</div></details>'''

html=f'''<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pesquisa de Mercado Shopee — {FORN}</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
:root{{--grad:linear-gradient(135deg,#5e3585,#9b4ede);--gradtext:linear-gradient(135deg,#b07ce0,#d8b9fa)}}
body{{background:#000;color:#f2eef7;font-family:'Poppins',sans-serif;padding:24px 16px 80px;max-width:1180px;margin:0 auto}}
.mono{{font-variant-numeric:tabular-nums}}
h1{{font-weight:800;font-size:clamp(22px,4vw,34px);letter-spacing:-.5px;color:#fff}}
h1 span{{background:var(--gradtext);-webkit-background-clip:text;background-clip:text;color:transparent}}
.linha{{width:100%;height:5px;border-radius:3px;background:var(--grad);margin:10px 0 14px}}
h2{{color:#fff}}
@keyframes pulsar{{0%{{transform:scale(1)}}50%{{transform:scale(1.045)}}100%{{transform:scale(1)}}}}
.topo{{text-align:center;margin-bottom:26px}}
.topo .logo{{max-height:62px;max-width:195px;margin:0 auto 12px;display:inline-block}}
.topo .linha{{margin:12px auto 0}}
.roxo{{background:var(--gradtext);-webkit-background-clip:text;background-clip:text;color:transparent}}
.kpis{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:26px}}
.kpi{{background:#120e17;border:1px solid #3a2d4a;border-radius:14px;padding:16px;transition:border-color .2s}}
.kpi:hover{{animation:pulsar .9s ease-in-out infinite;border-color:#9b4ede}}
.kpi .v{{font-size:26px;font-weight:800;color:#fff}} .kpi .l{{font-size:12px;color:#b3a6c4;margin-top:2px}}
.kpi.brand{{background:var(--grad);border:none}} .kpi.brand .v,.kpi.brand .l{{color:#fff}}
.kpi.hverde:hover{{background:#16a34a;border-color:#16a34a}}
.kpi.hamarelo:hover{{background:#ffd400;border-color:#ffd400}}
.kpi.hvermelho:hover{{background:#dc2626;border-color:#dc2626}}
.kpi.hlaranja:hover{{background:#f97316;border-color:#f97316}}
.kpi.hverde:hover .v,.kpi.hamarelo:hover .v,.kpi.hvermelho:hover .v,.kpi.hlaranja:hover .v,
.kpi.hverde:hover .l,.kpi.hamarelo:hover .l,.kpi.hvermelho:hover .l,.kpi.hlaranja:hover .l{{color:#fff!important}}
.painel{{background:#120e17;border:1px solid #2c2338;border-radius:14px;padding:18px;margin-bottom:26px}}
.painel h2{{font-size:16px;margin-bottom:12px;font-weight:700}} .painel h2 em{{color:#b3a6c4;font-style:normal;font-weight:400;font-size:13px}}
table{{width:100%;border-collapse:collapse;font-size:13px}}
th{{text-align:left;color:#b3a6c4;font-weight:600;padding:8px 10px;border-bottom:2px solid #2c2338;white-space:nowrap}}
td{{padding:8px 10px;border-bottom:1px solid #201a29;vertical-align:top;color:#e6dff0}}
#geral tbody tr{{cursor:pointer}} #geral tbody tr:hover{{background:#1a1322}}
.destaque{{font-weight:700;background:var(--gradtext);-webkit-background-clip:text;background-clip:text;color:transparent}}
.badge{{padding:3px 10px;border-radius:999px;font-size:11.5px;font-weight:700;white-space:nowrap}}
.fam{{background:#120e17;border:1px solid #2c2338;border-radius:14px;margin-bottom:12px;overflow:hidden}}
.fam summary{{display:flex;align-items:center;gap:12px;padding:14px 16px;cursor:pointer;list-style:none}}
.fam summary:hover{{background:#1a1322}}
.fam summary::-webkit-details-marker{{display:none}}
.vbar{{width:5px;height:26px;border-radius:3px;flex:none}}
.ftit{{font-weight:600;flex:1;color:#f2eef7}}
.fbody{{padding:4px 18px 18px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px;margin:10px 0 14px}}
.grid div{{background:#0c0910;border:1px solid #2c2338;border-radius:10px;padding:10px 12px;transition:border-color .2s}}
.grid div:hover{{animation:pulsar .9s ease-in-out infinite;border-color:#9b4ede}}
.grid span{{display:block;font-size:11px;color:#b3a6c4;margin-bottom:3px}}
.grid b{{font-size:14px;color:#fff}}
.motivo{{background:#0c0910;border-left:4px solid;border-image:var(--grad) 1;padding:12px 14px;font-size:13.5px;line-height:1.55;color:#d9d0e6;margin-bottom:14px}}
.conc a{{color:#c9a2f5;text-decoration:none;font-weight:600}} .conc a:hover{{text-decoration:underline}}
.calc{{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;align-items:end}}
.calc label{{display:block;font-size:12px;color:#b3a6c4;margin-bottom:4px}}
.calc input{{width:100%;background:#0c0910;border:1px solid #3a2d4a;border-radius:8px;color:#fff;padding:10px;font-family:'Poppins',sans-serif;font-size:15px}}
.calc input:focus{{outline:2px solid #9b4ede66;border-color:#9b4ede}}
.calc .res{{background:var(--grad);border-radius:10px;padding:10px 14px}}
.calc .res:hover{{animation:pulsar .9s ease-in-out infinite}}
.calc .res label{{color:#eadcfb}} .calc .res b{{color:#fff;font-size:20px}} .calc .res div{{color:#eadcfb!important}}
.premissas{{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px}}
.premissa{{background:#120e17;border:1px solid #2c2338;border-radius:12px;padding:14px 16px;font-size:13px;color:#c9bfd8;line-height:1.6;transition:border-color .2s}}
.premissa:hover{{animation:pulsar .9s ease-in-out infinite;border-color:#9b4ede}}
.premissa b{{background:var(--gradtext);-webkit-background-clip:text;background-clip:text;color:transparent;display:block;margin-bottom:4px;font-size:13.5px}}
.rodape{{text-align:center;color:#b3a6c4;font-size:13px;margin-top:44px;padding-top:18px;border-top:1px solid #2c2338}}
@media(max-width:760px){{ .tabelawrap{{overflow-x:auto}} }}
</style></head><body>
<header class="topo">
<img class="logo" src="https://lariiraha.com.br/materiais/uploads/logo-desbravando.png" alt="Desbravando as Vendas">
<h1>Pesquisa de Mercado <span>Shopee</span> — {FORN}</h1>
</header>

<div class="kpis">
<div class="kpi brand"><div class="v">35</div><div class="l">famílias de produto analisadas</div></div>
<div class="kpi hverde"><div class="v" style="color:#22c55e">{n_sim}</div><div class="l">SIM — consegue concorrer</div></div>
<div class="kpi hamarelo"><div class="v" style="color:#ffd400">{n_at}</div><div class="l">ATENÇÃO — só com ajustes</div></div>
<div class="kpi hvermelho"><div class="v" style="color:#ef4444">{n_nao}</div><div class="l">NÃO — fora de preço</div></div>
<div class="kpi hlaranja"><div class="v" style="color:#f97316">{tot_ads}</div><div class="l">anúncios da concorrência coletados</div></div>
</div>

<div class="painel">
<h2>Calculadora de precificação <em>(edite o custo e veja o preço com as taxas + 15%)</em></h2>
<div class="calc">
<div><label>Custo do produto (R$)</label><input id="cc" type="number" value="58.90" step="0.10" oninput="calc()"></div>
<div><label>Margem desejada (%)</label><input id="cm" type="number" value="15" step="1" oninput="calc()"></div>
<div><label>Imposto (%)</label><input id="ci" type="number" value="8" step="1" oninput="calc()"></div>
<div class="res"><label>Preço de venda</label><b id="cp" class="mono">—</b><div id="cd" style="font-size:11px;color:#9aa0ab;margin-top:3px"></div></div>
</div></div>

<div class="painel tabelawrap">
<h2><span class="roxo">Visão geral — todas as famílias</span> <em>(clique na linha para ver os detalhes)</em></h2>
<table id="geral"><thead><tr><th>#</th><th>Família de produto</th><th>Custo</th><th>Preço c/ 15%</th><th>Menor</th><th>Mediana</th><th>Média</th><th>Maior</th><th>Conc.</th><th>Formato</th><th>Veredicto</th></tr></thead>
<tbody>{rows}</tbody></table></div>

<h2 style="margin:26px 0 12px;font-size:19px"><span class="roxo">Análise detalhada por família</span> <span style="color:#6b7280;font-weight:400;font-size:13px">(clique para abrir — links dos anúncios da concorrência dentro)</span></h2>
{cards}

<h2 style="margin:26px 0 12px;font-size:19px">Premissas e limitações</h2>
<div class="premissas">
<div class="premissa"><b>Custo do fornecedor</b>Coluna AVISTA da tabela Dricar Jan/2026. Famílias com variação de tamanho ou material mostram a faixa de custo; o cálculo usa o menor valor.</div>
<div class="premissa"><b>Fórmula de precificação</b>Preço = (custo + taxa fixa) ÷ (1 − comissão − 8% de imposto − 15% de margem), testando cada faixa de comissão até o preço cair dentro dela.</div>
<div class="premissa"><b>Programas não incluídos</b>Frete Grátis (CCC), Shopee Antecipa, Devolução Fácil e Eventos Oficiais ficaram fora do cálculo. Participando deles, some cerca de 2% a 6% de custo e o preço sobe.</div>
<div class="premissa"><b>Coleta da concorrência</b>Top resultados da busca Shopee por relevância em {HOJE}, até 14 anúncios por família, com preços promocionais vigentes. Vendas por anúncio não estavam expostas nos cards — a comparação usa preço, avaliação e posição.</div>
<div class="premissa"><b>Por que a mediana</b>Buscas com resultados mistos (ex.: capas de cobrir) têm a média inflada por itens premium. O veredicto usa a mediana, que representa melhor o concorrente típico.</div>
<div class="premissa"><b>Dricar já vende na Shopee</b>A marca aparece como filtro em várias categorias (Kombi, kit 9 peças, estepe, capa frontal, poliéster). Você concorrerá também com outros revendedores do mesmo fornecedor.</div>
<div class="premissa"><b>Uso do relatório</b>Análise de mercado, não garantia de vendas. Teste com poucos SKUs antes de comprar volume.</div>
</div>

<script>
const FX=[[0,79.99,0.20,4],[80,99.99,0.14,16],[100,199.99,0.14,20],[200,499.99,0.14,26],[500,1e12,0.14,26]];
function calc(){{
 const c=parseFloat(document.getElementById('cc').value)||0;
 const m=(parseFloat(document.getElementById('cm').value)||0)/100;
 const i=(parseFloat(document.getElementById('ci').value)||0)/100;
 let out=null,fx=null;
 for(const [lo,hi,com,fixa] of FX){{const tot=com+i+m;if(tot>=1)continue;const p=(c+fixa)/(1-tot);if(p>=lo&&p<=hi){{out=p;fx=[com,fixa];break}}}}
 if(!out){{for(const [lo,hi,com,fixa] of FX){{const tot=com+i+m;if(tot>=1)continue;out=(c+fixa)/(1-tot);fx=[com,fixa]}}}}
 document.getElementById('cp').textContent=out?out.toLocaleString('pt-BR',{{style:'currency',currency:'BRL'}}):'inviável';
 document.getElementById('cd').textContent=fx?`comissão ${{(fx[0]*100).toFixed(0)}}% + R$ ${{fx[1].toFixed(2)}} · lucro ${{(out*m).toLocaleString('pt-BR',{{style:'currency',currency:'BRL'}})}}`:'';
}}
calc();
</script>
<footer class="rodape">© 2026 Desbravando · Todos os direitos reservados.</footer>
</body></html>'''

open('pesquisa-mercado-shopee-dricar-2026-07-23.html','w').write(html)
print('ok', len(html))
