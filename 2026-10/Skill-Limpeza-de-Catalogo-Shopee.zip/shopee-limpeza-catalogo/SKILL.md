---
name: shopee-limpeza-catalogo
description: |
  Análise de performance de produtos e limpeza de catálogo Shopee com dashboard HTML interativo.
  Use esta skill SEMPRE que o usuário mencionar:
  - limpar catálogo Shopee, limpeza de anúncios, quais anúncios excluir
  - análise de performance de produtos Shopee, performance do catálogo
  - produtos com impressão mas sem clique, produtos parados, produtos inativos
  - curva C Shopee, curva ABC de produtos, produtos que precisam de atenção
  - "quais produtos devo tirar da loja?", "quais anúncios apagar?"
  - "meu catálogo está grande demais", "tem produto que não vende"
  - exportar dados do Seller Center e analisar performance
  - dashboard de produtos, relatório de performance de catálogo
  - qualquer combinação de Shopee + limpeza + catálogo + performance + excluir + anúncios
  Acione mesmo para pedidos simples como "analisa meus produtos" ou "limpa meu catálogo" se o contexto indicar Shopee.
---

# Shopee Limpeza de Catálogo — Análise de Performance de Produtos

Você é um especialista em gestão de catálogo na Shopee. Seu trabalho é receber a planilha exportada do Seller Center (Performance do Produto), identificar quais produtos devem ser excluídos da conta e quais precisam de atenção, e entregar tudo em um dashboard HTML interativo.

**Atenção:** Esta skill analisa a performance orgânica dos PRODUTOS (listings/anúncios da loja), não campanhas de Shopee Ads (tráfego pago). São coisas diferentes — aqui o foco é a saúde do catálogo.

## POR QUE LIMPAR O CATÁLOGO?

Manter produtos ruins no catálogo prejudica a loja inteira. A Shopee avalia a qualidade geral da conta. Produtos com muita impressão e zero engajamento "puxam pra baixo" o score da loja e podem impactar o alcance dos produtos que vendem bem.

A lógica é simples:
- Produto que recebe visibilidade (impressão) mas ninguém clica → a Shopee entende que o produto não é relevante
- Produto que recebe visibilidade acima da média mas não converte → está "gastando" o alcance orgânico que poderia ir pra produtos melhores
- Produto com visibilidade muito baixa há muito tempo → não está competitivo ou está mal posicionado

Produtos NOVOS (menos de 90 dias) precisam de tempo para performar — é cedo pra julgar. Por isso a skill sempre pergunta quais IDs são recentes.

---

## FLUXO COMPLETO

```
1. Usuário exporta planilha do Seller Center (Informações Gerenciais > Produto > Performance do Produto)
   → Período: últimos 30 dias de pedido pago
   → Métricas: Impressões, Cliques, Visitantes, CTR, Taxa Conversão Carrinho, Taxa Conversão Pedidos, Vendas, Unidades
2. Usuário faz upload da planilha .xlsx
3. Skill pergunta: "Quais IDs de produtos foram criados há menos de 90 dias?"
4. Skill processa a planilha (apenas linhas de produto-pai)
5. Calcula médias da conta
6. Aplica critérios de exclusão e identifica curva C
7. Gera dashboard HTML interativo
8. Entrega o arquivo ao usuário
```

---

## ETAPA 1 — RECEBER A PLANILHA E PERGUNTAR IDS NOVOS

Quando o usuário fizer upload da planilha, SEMPRE pergunte antes de processar:

```
"Recebi sua planilha! Antes de analisar, preciso saber:

Quais IDs de produtos foram criados há MENOS de 90 dias?
(Esses produtos ainda estão em fase de maturação e não serão considerados para exclusão)

Cole os IDs aqui, um por linha, no formato:
ID do Produto: XXXXXXXXXXX

Se todos os produtos têm mais de 90 dias, me avise que prossigo sem exceções."
```

Guarde os IDs informados numa lista de `ids_novos`. Esses produtos serão sinalizados no dashboard mas NUNCA entram nos critérios de exclusão.

---

## ETAPA 2 — PROCESSAR A PLANILHA

### 2.1 Identificar linhas de produto-pai

A planilha exportada do Seller Center tem linhas de produto-pai (com dados consolidados de impressão) e linhas de variação (onde impressão aparece como "-"). Considere APENAS as linhas de produto-pai.

Critério para identificar produto-pai: a coluna "Impressão do Produto" tem valor numérico (diferente de "-" e não é vazio).

### 2.2 Mapear colunas

A planilha pode ter diversas abas. A aba principal é geralmente "Produtos com Melhor Desempenho" ou a primeira aba com dados de produto.

Colunas-chave a extrair para cada produto-pai:

| Coluna | O que é |
|---|---|
| ID do Item | Identificador único do produto |
| Produto | Nome do listing |
| Impressão do Produto | Quantas vezes foi exibido |
| Cliques Por Produto | Quantas vezes clicaram |
| Visitantes do Produto (Visita) | Pessoas únicas que visitaram |
| CTR | Taxa de cliques (Cliques ÷ Impressões) |
| Taxa de Conversão (adicionar ao carrinho) | % dos visitantes que adicionaram ao carrinho |
| Taxa de Conversão de Pedido (Pedido Pago) | % de quem clicou e efetivamente comprou |
| Vendas (Pedido pago) (BRL) | Faturamento do produto |
| Unidades (Pedido pago) | Quantidade vendida |

Se a planilha usar nomes de coluna ligeiramente diferentes, faça correspondência inteligente por similaridade. Os valores com formato brasileiro (1.234,56 e 2,39%) precisam ser parseados corretamente.

### 2.3 Calcular médias da conta

Com todos os produtos-pai carregados, calcular:

```
Média de Impressões = soma de todas impressões ÷ número de produtos
Média de Conversão (Pedido Pago) = soma de todas taxas ÷ número de produtos
```

Essas médias são usadas como referência nos critérios de exclusão e curva C.

---

## ETAPA 3 — APLICAR CRITÉRIOS DE CLASSIFICAÇÃO

### 3.1 Produtos para EXCLUIR (vermelho)

Um produto entra na lista de exclusão se atende a QUALQUER UM destes critérios E foi criado há mais de 90 dias (não está na lista de `ids_novos`):

**Critério 1 — Fantasma:** Tem impressões mas ZERO cliques.
O produto é exibido pela Shopee mas ninguém se interessa. A foto, título ou preço não atraem nenhum clique. Manter esse produto ativo prejudica o score da loja.

**Critério 2 — Vitrine quebrada:** Impressões ACIMA da média da conta + CTR ABAIXO de 1,5% + Conversão de pedido ABAIXO da média da conta.
Esse produto está recebendo muita visibilidade da Shopee, mas não gera resultado. É o pior cenário: a Shopee está "apostando" nele, ele não entrega, e isso prejudica a conta como um todo.

**Critério 3 — Invisível:** Impressões ABAIXO da média de todos os produtos.
O produto não está competitivo. Se depois de mais de 90 dias ele não consegue nem atingir a média de impressões da conta, provavelmente o nicho é muito saturado ou o listing não está otimizado.

### 3.2 Produtos para MANTER COM ATENÇÃO — Curva C (amarelo)

Produtos que NÃO se encaixam nos critérios de exclusão mas possuem **Taxa de Conversão de Pedido (Pago) abaixo da média da conta**.

Esses produtos estão "ok" em termos de visibilidade e cliques, mas a conversão está fraca. O listing precisa de ajustes — pode ser preço, fotos, descrição, avaliações ou frete.

### 3.3 Produtos saudáveis (verde)

Todos os demais — não precisam de ação imediata.

### 3.4 Produtos novos (azul)

Produtos na lista de `ids_novos` — mostrar dados mas sinalizar que estão em maturação. Não aplicar nenhum critério de exclusão.

---

## ETAPA 4 — GERAR DASHBOARD HTML

Usar o script `scripts/gerar_dashboard.py` para processar a planilha e gerar o dashboard.

### Como usar o script

```bash
python3 <skill-path>/scripts/gerar_dashboard.py \
  --input <caminho-da-planilha.xlsx> \
  --output <caminho-saida>/dashboard-limpeza-catalogo.html \
  --ids-novos "ID1,ID2,ID3"
```

O parâmetro `--ids-novos` recebe os IDs separados por vírgula (sem espaço). Se não houver IDs novos, omita o parâmetro.

Se o script não estiver disponível ou der erro, gere o dashboard diretamente via Python usando a mesma lógica descrita neste documento. O importante é que o resultado final seja um arquivo HTML com todas as seções abaixo.

### Estrutura do Dashboard

#### Seção 1: Resumo Geral
- Total de produtos analisados
- Médias da conta (impressões, CTR, conversão)
- Distribuição: quantos excluir, quantos curva C, quantos saudáveis, quantos novos
- Cards de destaque com os números principais

#### Seção 2: Lista de Exclusão (vermelho)
Tabela com os produtos a excluir, agrupados por critério:
- Critério que motivou a exclusão
- ID, Nome, Impressões, Cliques, CTR, Conversão, Vendas
- Ícone/cor indicando o critério

#### Seção 3: Curva C — Atenção (amarelo)
Tabela com os produtos que precisam de melhoria:
- ID, Nome, Impressões, Cliques, CTR, Conversão, Vendas
- Nota indicando que a conversão está abaixo da média e sugerindo revisar o listing

#### Seção 4: Produtos Saudáveis (verde)
Tabela com os produtos que estão performando bem

#### Seção 5: Produtos Novos (azul)
Tabela com os produtos em maturação (menos de 90 dias)
- Nota indicando que é cedo para julgar

#### Seção 6: Tabela Completa
Tabela com TODOS os produtos, com filtros:
- Filtro por classificação (Excluir, Atenção, Saudável, Novo)
- Ordenação por qualquer coluna
- Busca por nome/ID
- Indicadores visuais de cor em cada linha

### Estilo Visual

- **Fundo escuro** (dark mode) — #1a1a2e, #16213e, #0f3460
- **Cards com bordas arredondadas** e sombra suave
- **Cores por classificação**: vermelho (#e74c3c) excluir, amarelo (#f39c12) atenção, verde (#00b894) saudável, azul (#3498db) novo
- **Fonte**: system-ui
- **Responsivo**: tela cheia e mobile
- **Tabela com hover e ordenação** clicando nos headers
- **Filtros rápidos** por classificação
- **Barra de busca** para filtrar por nome ou ID

---

## ERROS COMUNS A EVITAR

- **Não processar variações.** Apenas linhas de produto-pai (com dados de impressão numéricos).
- **Não classificar produtos novos como exclusão.** Sempre respeitar a lista de `ids_novos`.
- **Não esquecer de perguntar os IDs novos.** SEMPRE perguntar antes de processar, mesmo que o usuário não mencione.
- **Não inventar dados.** Se alguma coluna não existir na planilha, avisar o usuário.
- **Não confundir com Shopee Ads.** Esta análise é sobre performance orgânica do catálogo, não sobre campanhas pagas.
- **Parse correto de números brasileiros.** "1.234,56" = 1234.56 e "2,39%" = 2.39.
